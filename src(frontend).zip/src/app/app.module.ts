import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { LoanOfferComponent } from './loan-offer/loan-offer.component';
import { EmiSchedularComponent } from './emi-schedular/emi-schedular.component';
import { HomePageComponent } from './home-page/home-page.component';
import { AddLoanDetailsComponent } from './add-loan-details/add-loan-details.component';
import { AddDocumentDetailsComponent } from './add-document-details/add-document-details.component';
import { AddIncomeDetailsComponent } from './add-income-details/add-income-details.component';
import { AddPersonalDetailsComponent } from './add-personal-details/add-personal-details.component';
import { AddVehicleDetailsComponent } from './add-vehicle-details/add-vehicle-details.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { VehicleLoanService } from './vehicle-loan.service';
import { LoginDetailsComponent } from './login-details/login-details.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ClientComponent } from './client/client.component';

@NgModule({
  declarations: [
    AppComponent,
    AdminLoginComponent,
    AdminDashboardComponent,
    UserLoginComponent,
    UserDashboardComponent,
    LoanOfferComponent,
    EmiSchedularComponent,
    HomePageComponent,
    AddLoanDetailsComponent,
    AddDocumentDetailsComponent,
    AddIncomeDetailsComponent,
    AddPersonalDetailsComponent,
    AddVehicleDetailsComponent,
    AboutUsComponent,
    LoginDetailsComponent,
    ClientComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [VehicleLoanService],
  bootstrap: [AppComponent]
})
export class AppModule { }
