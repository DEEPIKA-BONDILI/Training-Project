import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { DocumentDTO, IncomeDTO, LoanDTO, LoginDTO, User, VehicleDTO } from './user';

@Injectable({
  providedIn: 'root'
})
export class VehicleLoanService {

  constructor(private myHttp: HttpClient) { }

  findUserByUserIdService(logDTO: LoginDTO) {
    return this.myHttp.post<any>("http://localhost:8080/findUser/",logDTO);
    }

    findUserByUserIdService1(num: number) : Observable<User> {
      return this.myHttp.get<User>("http://localhost:8080/getUser/"+num);
      }

      addNewUserService(myUser : User) : Observable<User> {
        return this.myHttp.post<User>("http://localhost:8080/addUser/",myUser);
        }

      findUsersService():Observable<User[]>{
        return this.myHttp.get<User[]>("http://localhost:8080/getUsers");
        }
   
        addIncomeService(myincome:IncomeDTO) {
          return this.myHttp.post<any>("http://localhost:8080/addIncome/",myincome);
          }

          addVehicleService(myvehicle:VehicleDTO) {
            return this.myHttp.post<any>("http://localhost:8080/addVehicle/",myvehicle);
            }

            addLoanService(myloan:LoanDTO) {
              return this.myHttp.post<any>("http://localhost:8080/addLoan/",myloan);
              }

              addDocumentService(mydoc:DocumentDTO) {
                return this.myHttp.post<any>("http://localhost:8080/addIncome/",mydoc);
                }
}
