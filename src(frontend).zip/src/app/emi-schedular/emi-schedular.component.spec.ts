import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmiSchedularComponent } from './emi-schedular.component';

describe('EmiSchedularComponent', () => {
  let component: EmiSchedularComponent;
  let fixture: ComponentFixture<EmiSchedularComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmiSchedularComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmiSchedularComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
