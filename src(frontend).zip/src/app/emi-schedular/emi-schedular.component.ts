import { Component, OnInit } from '@angular/core';

 @Component({
  selector: 'app-emi-schedular',
  templateUrl: './emi-schedular.component.html',
   styleUrls: ['./emi-schedular.component.css']
 })
export class EmiSchedularComponent implements OnInit {

  constructor() { }



  p: number = 0;
  n: number =0
  r: number =0
  si: number =0;

   ngOnInit(): void {
   }

   calculateSI() {
     this.si = (this.p*this.n*this.r)/1200;
   }
 }

