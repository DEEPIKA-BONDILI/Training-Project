import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginDetailsComponent } from '../login-details/login-details.component';
import { LoginDTO, User } from '../user';
import { VehicleLoanService } from '../vehicle-loan.service';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

  // constructor() { }

  constructor(private router:Router,private vloan : VehicleLoanService) { }

  tempUser: User = new User();
  loginInfo: LoginDTO = new LoginDTO();

  // userdashboard():void{
  //   this.router.navigate(["user-dashboard"]);
  // }

  authenticate() {
    this.vloan.findUserByUserIdService(this.loginInfo).subscribe((data:User)=>{
        this.tempUser=data;
        console.log(data);
        console.log(this.tempUser);
        sessionStorage.setItem("MYUSER",JSON.stringify(this.tempUser));
        this.router.navigate(["user-dashboard"]);
        
       }, (err) => {

            alert('USER NOT FOUND');

       }
       )

  }
 /*
  authenticate1() {
    this.vloan.findUserByUserIdService1(this.loginInfo.userId).subscribe((data:User)=>{
      if(data!=null){
        this.tempUser=data;
        console.log(data);
        console.log(this.tempUser);
        sessionStorage.setItem("MYUSER",JSON.stringify(this.tempUser));
       }else{
          alert('unable to fetch');
       }
   })

  }*/

  ngOnInit(): void {
    this.tempUser.userId=0;
  }

}
