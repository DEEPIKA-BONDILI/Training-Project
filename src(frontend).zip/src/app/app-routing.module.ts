import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { AddDocumentDetailsComponent } from './add-document-details/add-document-details.component';
import { AddIncomeDetailsComponent } from './add-income-details/add-income-details.component';
import { AddLoanDetailsComponent } from './add-loan-details/add-loan-details.component';
import { AddPersonalDetailsComponent } from './add-personal-details/add-personal-details.component';
import { AddVehicleDetailsComponent } from './add-vehicle-details/add-vehicle-details.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { ClientComponent } from './client/client.component';
import { EmiSchedularComponent } from './emi-schedular/emi-schedular.component';
import { HomePageComponent } from './home-page/home-page.component';
import { LoanOfferComponent } from './loan-offer/loan-offer.component';
import { LoginDetailsComponent } from './login-details/login-details.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { UserLoginComponent } from './user-login/user-login.component';

const routes: Routes = [

  { path:'',redirectTo:"/home-page",pathMatch:'full'},
  {path:'home',component: HomePageComponent,
  children:
   [
    {path :'add-loan-details',component:AddLoanDetailsComponent},
    {path :'add-income-details',component:AddIncomeDetailsComponent} 
  ]},
  {path :'add-loan-details',component:AddLoanDetailsComponent},
  {path :'add-income-details',component:AddIncomeDetailsComponent},
  {path :'add-vehicle-details',component:AddVehicleDetailsComponent},
  {path :'add-document-details',component:AddDocumentDetailsComponent},
  {path :'add-personal-details',component:AddPersonalDetailsComponent},
  {path :'admin-login',component:AdminLoginComponent},
  {path :'admin-dashboard',component:AdminDashboardComponent},
  {path :'user-login',component:UserLoginComponent},
  {path :'user-dashboard',component:UserDashboardComponent},
  {path :'home-page',component:HomePageComponent},
  {path :'emi-schedular',component:EmiSchedularComponent},
  {path :'loan-offer',component:LoanOfferComponent},
  {path :'about-us' ,component:AboutUsComponent},
  {path : 'login-details',component:LoginDetailsComponent},
  {path :'client',component:ClientComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
