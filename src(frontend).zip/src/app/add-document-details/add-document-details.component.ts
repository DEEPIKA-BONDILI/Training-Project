import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DocumentDTO, User } from '../user';
import { VehicleLoanService } from '../vehicle-loan.service';

@Component({
  selector: 'app-add-document-details',
  templateUrl: './add-document-details.component.html',
  styleUrls: ['./add-document-details.component.css']
})
export class AddDocumentDetailsComponent implements OnInit {
  mydata : any | undefined;
  tempUser: User = new User();
  mydoc: DocumentDTO=new DocumentDTO();
  constructor(private router:Router, private vloan:VehicleLoanService) { }
  //addDocDetails(mydoc:DocumentDTO){
    addDocDetails(){
      this.router.navigate(["user-dashboard"]);
    this.vloan.addDocumentService(this.mydoc).subscribe((data)=>{
      if(data!=null){
        alert(this. mydoc);
        console.log(data);
        alert(data);
        sessionStorage.setItem("MYDOCUMENT",JSON.stringify(this.mydoc));
        alert("Added successfully");
        
      }},
      (err)=>{
        // alert("some thing went wrong");
        console.log(err);
      })
    }

  ngOnInit(): void {
    this.mydata = sessionStorage.getItem("MYUSER");  
    this.tempUser = JSON.parse(this.mydata);
  }

}
