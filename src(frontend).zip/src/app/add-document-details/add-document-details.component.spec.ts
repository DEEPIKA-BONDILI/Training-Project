import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddDocumentDetailsComponent } from './add-document-details.component';

describe('AddDocumentDetailsComponent', () => {
  let component: AddDocumentDetailsComponent;
  let fixture: ComponentFixture<AddDocumentDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddDocumentDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddDocumentDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
