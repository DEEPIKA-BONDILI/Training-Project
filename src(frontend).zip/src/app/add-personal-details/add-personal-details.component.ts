import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../user';
import { VehicleLoanService } from '../vehicle-loan.service';

@Component({
  selector: 'app-add-personal-details',
  templateUrl: './add-personal-details.component.html',
  styleUrls: ['./add-personal-details.component.css']
})
export class AddPersonalDetailsComponent implements OnInit {

  dno=0;

  myUser: User=new User();

  constructor(private router:Router,private vloan:VehicleLoanService,private myhttp:HttpClient) { }

  adduserdetails(myUser:User){
   // adduserdetails(){
    this.router.navigate(["user-login"]);
    this.vloan.addNewUserService(myUser).subscribe((data)=>{
 
   if(data!=null){
     
  alert(this.myUser);
        
  console.log(data);
  alert(data);
        
 alert("added successfully");
 
       }},
       
 (err)=>{
         
//  alert("something went wrong"); 
 console.log(err);
      
  })
  }

  ngOnInit(): void {
  }

}



 
 