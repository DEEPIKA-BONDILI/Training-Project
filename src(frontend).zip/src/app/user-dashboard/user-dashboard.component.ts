import { Component, OnInit } from '@angular/core';
import { LoginDTO, User } from '../user';
import { VehicleLoanService } from '../vehicle-loan.service';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit {

  constructor(private vls: VehicleLoanService ) { }

  ngOnInit(): void {
    this.mydata = sessionStorage.getItem("MYUSER");  
    this.tempUser = JSON.parse(this.mydata);
  }
  tempUser: User = new User();

  loginInfo: LoginDTO = new LoginDTO();
  mydata: any;
  // showUserDashBoard() {
   
  // this.vls.findUserByUserIdService(this.loginInfo).subscribe((data:User)=>{
  //       if(data!=null){
  //         this.tempUser=data;
  //         console.log(data);
  //         console.log(this.tempUser);
  //         // this.mydata = sessionStorage.getItem("MYUSER");  
  //         // this.tempUser = JSON.parse(this.mydata);
  //         // console.log(this.tempUser);
  //       }else{
  //           alert('unable to fetch');
  //         }
  //     })
  //    }


    // mydata: any;
    
    // DisplayUserDetails() {
      // this.mydata = sessionStorage.getItem("MYUSER");  
      // this.tempUser = JSON.parse(this.mydata);
    // }


}

