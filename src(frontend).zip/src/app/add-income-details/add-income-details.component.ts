import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IncomeDTO, User } from '../user';
import { VehicleLoanService } from '../vehicle-loan.service';

@Component({
  selector: 'app-add-income-details',
  templateUrl: './add-income-details.component.html',
  styleUrls: ['./add-income-details.component.css']
})
export class AddIncomeDetailsComponent implements OnInit {
  mydata: any;
  tempUser: User = new User();
  myincome: IncomeDTO=new IncomeDTO();
  constructor(private router:Router, private vloan:VehicleLoanService) { }
  // addIncomedetails(myincome:IncomeDTO){
    addIncomedetails(){
      this.router.navigate(["add-vehicle-details"]);
      this.myincome.userId=this.tempUser.userId;
    this.vloan.addIncomeService(this.myincome).subscribe((data)=>{
      if(data!=null){
        alert(this. myincome);
        sessionStorage.setItem("MYINCOME",JSON.stringify(this.myincome));
        alert(data);
        alert("adding is successful");
       
      }},
      (err)=>{
        // alert("some thing went wrong");
        console.log(err);
      })
  }  

  ngOnInit(): void {

    this.mydata = sessionStorage.getItem("MYUSER");  
    this.tempUser = JSON.parse(this.mydata);
  }
}


