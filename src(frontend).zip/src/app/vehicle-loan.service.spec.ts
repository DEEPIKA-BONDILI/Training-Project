import { TestBed } from '@angular/core/testing';

import { VehicleLoanService } from './vehicle-loan.service';

describe('VehicleLoanService', () => {
  let service: VehicleLoanService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VehicleLoanService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
