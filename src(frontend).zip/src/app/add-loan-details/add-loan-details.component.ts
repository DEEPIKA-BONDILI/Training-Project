import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IncomeDTO, LoanDTO, User, VehicleDTO } from '../user';
import { VehicleLoanService } from '../vehicle-loan.service';

@Component({
  selector: 'app-add-loan-details',
  templateUrl: './add-loan-details.component.html',
  styleUrls: ['./add-loan-details.component.css']
})
export class AddLoanDetailsComponent implements OnInit {
  mydata: any  | undefined;
  mydata1: any  | undefined;
  mydata2: any  | undefined;
  tempUser: User = new User();
  myincome: IncomeDTO=new IncomeDTO();
  myvehicle : VehicleDTO =new VehicleDTO();
  
  myloan: LoanDTO=new LoanDTO();
  constructor(private router:Router, private vloan:VehicleLoanService) { }
  // addLoanDetails(myloan:LoanDTO){
    addLoanDetails(){
      this.router.navigate(["add-document-details"]);
    this.vloan.addLoanService(this.myloan).subscribe((data)=>{
      if(data!=null){
        alert(this. myloan);
        console.log(data);
        alert(data);
        sessionStorage.setItem("MYLOAN",JSON.stringify(this.myloan));
        alert("adding is successful");
        
      }},
      (err)=>{
        // alert("some thing went wrong");
        console.log(err);
      })
  }

  ngOnInit(): void {
    this.mydata = sessionStorage.getItem("MYUSER");  
    this.tempUser = JSON.parse(this.mydata);
    this.mydata1=sessionStorage.getItem("MYINCOME");
    this.myincome = JSON.parse(this.mydata1);
    this.mydata2=sessionStorage.getItem("MYVEHICLE");
    this.myvehicle = JSON.parse(this.mydata2);
  }

}
