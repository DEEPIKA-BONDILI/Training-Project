import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IncomeDTO, User, Vehicle, VehicleDTO } from '../user';
import { VehicleLoanService } from '../vehicle-loan.service';

@Component({
  selector: 'app-add-vehicle-details',
  templateUrl: './add-vehicle-details.component.html',
  styleUrls: ['./add-vehicle-details.component.css']
})
export class AddVehicleDetailsComponent implements OnInit {
  mydata: any;
  mydata1: any;
  tempUser: User = new User();
  myincome: IncomeDTO=new IncomeDTO();
  myvehicle : VehicleDTO =new VehicleDTO();
  constructor(private router:Router,private vloan:VehicleLoanService) { }

  // addvehicledetails(myvehicle : VehicleDTO){
    addvehicledetails(){
      this.router.navigate(["add-loan-details"]);
      this.myvehicle.incomeId=98;//this.myincome.incomeId;
    this.vloan.addVehicleService(this.myvehicle).subscribe((data)=>{
      if(data!=null){
        alert(this.myvehicle);
        console.log(data);
        sessionStorage.setItem("MYVEHICLE",JSON.stringify(this.myvehicle));
        alert(data);
        alert("added successfully");
        
      }},
      (err)=>{
        // alert("some thing went wrong");
        console.log(err);
      })
  }  
  
  ngOnInit(): void {
    
    this.mydata = sessionStorage.getItem("MYUSER");  
    this.tempUser = JSON.parse(this.mydata);
    this.mydata1=sessionStorage.getItem("MYINCOME");
    this.myincome = JSON.parse(this.mydata1);
  }
}



  
    
