import { Component, OnInit } from '@angular/core';
import { LoginDTO, User } from '../user';
import { VehicleLoanService } from '../vehicle-loan.service';

@Component({
  selector: 'app-login-details',
  templateUrl: './login-details.component.html',
  styleUrls: ['./login-details.component.css']
})
export class LoginDetailsComponent implements OnInit {
  
  // loginInfo: LoginDTO = new LoginDTO();

uno=0;
mydata : any;
 constructor(private vloan : VehicleLoanService) { }
   tempUser:User=new User();
  findUserByUserId(uno:number){
  //  this.vloan.findUserByUserIdService(this.loginInfo).subscribe((data:User)=>{
    this.vloan.findUserByUserIdService1(uno).subscribe((data:User)=>{
    if(data!=null){
      this.tempUser=data;
     }else{
        alert('unable to fetch');
     }
 })
}


  ngOnInit(): void {

    this.mydata = sessionStorage.getItem("MYUSER");  
    this.tempUser = JSON.parse(this.mydata);

  }

}
