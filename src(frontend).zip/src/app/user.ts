export class User {
    userId:number =0;
    fname:string |undefined;
    mname:string |undefined;
    lname:string |undefined;
    mailid:string |undefined;
    password:string |undefined;
    confirmPassword:string |undefined;
    address:string |undefined;
    nationality:string |undefined;
    gender:string |undefined;
    phoneno:number |undefined;
    adharNo:number |undefined;
    dob:Date |undefined;
    panNo:string |undefined;
    docTables : Document[] | undefined;
    incomeTables : Income[] | undefined;
    //addr: Address | undefined;
    }

    export class LoginDTO {
        userId: number=0;
        password: string | undefined;
    }

    export class Income {
        incomeid:number |undefined;
        employername:string |undefined;
        organizationType:string |undefined;
        typeOfEmp:string |undefined;
        vehicletables : Vehicle[] | undefined;
        }

    export class IncomeDTO {
            incomeId:number=0;
            employerName:string |undefined;
            organizationType:string |undefined;
            typeOfEmp:string |undefined;
            userId : number | undefined;
            }   

    export class Vehicle {
            vehicleid:number |undefined;
            color:string |undefined;
            company:string |undefined;
            exshowroomprice:number |undefined;
            model:string |undefined;
            onroadprice:number |undefined;
            variant:string |undefined;
            loanTables : Loan[] | undefined;
            }    

    export class VehicleDTO {
                vehicleid:number |undefined;
                color:string |undefined;
                company:string |undefined;
                exshowroomprice:number |undefined;
                model:string |undefined;
                onroadprice:number |undefined;
                variant:string |undefined;
                incomeId:number |undefined;
                }            

    export class Loan {
                loanId:number |undefined;
                interestRate:number |undefined;
                loanAmount:number |undefined;
                maxLoan:number |undefined;
                tenure:number |undefined;
                }

     export class LoanDTO {
                    loanId:number |undefined;
                    interestRate:number |undefined;
                    loanAmount:number |undefined;
                    maxLoan:number |undefined;
                    tenure:number |undefined;
                    vehicleid:number |undefined;
                    }
    export class Document {
        docId:number | undefined;
        adhaarCard:string | undefined;
        panCard:string | undefined;
        salaryslip:string | undefined;
        loantrackerTables : Loantracker[] | undefined;
    }

    export class DocumentDTO {
        docId:number | undefined;
        adhaarCard:string | undefined;
        panCard:string | undefined;
        salaryslip:string | undefined;
        userId : number | undefined;
    }

    export class Loantracker {
        finalId:number |undefined;
        accNo:number |undefined;
        loanApprovalDate:Date |undefined;
        loanappId:number |undefined;
        } 

     export class LoantrackerDTO {
            finalId:number |undefined;
            accNo:number |undefined;
            loanApprovalDate:Date |undefined;
            loanappId:number |undefined;
            docId:number | undefined;
            } 
     
    /*class Address{
         street: string | undefined;
         city: string  | undefined;
    }*/

    


