import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../user';
import { VehicleLoanService } from '../vehicle-loan.service';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.css']
})
export class ClientComponent implements OnInit {

  constructor(private router:Router,private vloan : VehicleLoanService) { }

  tempUsers:User[] | undefined;
  findAllUsers(){
      this.vloan.findUsersService().subscribe((data : User[])=>{
       if(data!=null){
          this.tempUsers=data;
         console.log(data);     
  }else{
           alert('unable to fetch');
       }
  })
  }

  ngOnInit(): void {
  }

}
