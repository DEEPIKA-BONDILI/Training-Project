import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
AdminUserName:any;
AdminPassword: any;
  constructor(private router:Router) { }

  admindashboard():void{
    if(this.AdminUserName=="Admin" && this.AdminPassword=="Password"){
   
      this.router.navigate(["admin-dashboard"]);
    }else {
      alert('Invalid UserName Or Password');
    }
  }

  ngOnInit(): void {
  }

}
