package com.example.demo1;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo1.layer2.LoanTable;
import com.example.demo1.layer2.Vehicletable;
import com.example.demo1.layer3.LoanTableRepo;
import com.example.demo1.layer3.VehicleTableRepo;	


@SpringBootTest
public class LoanTableTestCases {

	@Autowired
	LoanTableRepo loanRepo;
	
	@Autowired
	VehicleTableRepo vehicleRepo;
	
	@Test
	public void testInsertNewLoan() {//successful
		
		LoanTable loan = new LoanTable();
		loan.setMaxLoan(30000000);
		loan.setInterestRate(15.25f);
		loan.setTenure(220);
		loan.setLoanAmount(160000000);
		//Vehicletable veh=vehicleRepo.findVehicletable(601);
		//loan.setVehicletable(veh);
		loanRepo.addLoanDetails(loan);
	}
	@Test											
	public void testLoanModify() { //creating another row
		LoanTable loan = new LoanTable();
		Vehicletable veh=vehicleRepo.findVehicle(605);  
		loanRepo.findLoanDetails(131); 
		loan.setLoanId(131);
		loan.setMaxLoan(200000000);
		loan.setInterestRate(12.25f);
		loan.setTenure(120);
		loan.setLoanAmount(16000000);
		loan.setVehicletable(veh);
		loanRepo.modifyLoanDetails(loan);
		
	}
	

	@Test
	public void testRemoveLoan() {//successful
		loanRepo.removeLoanDetails(301);
		
	}

	@Test
	public void testFindLoan() {//successful
		LoanTable loan=loanRepo.findLoanDetails(303);
		System.out.println(loan.getLoanId());
		System.out.println(loan.getMaxLoan());
		System.out.println(loan.getInterestRate());
		System.out.println(loan.getTenure());
		System.out.println(loan.getVehicletable().getVehicleid());
		System.out.println("-----------------");
		
	}
	
	
	@Test
	public void testFindAllloan() {//successful
		Set<LoanTable> loanSet = loanRepo.findAllLoanDetails();
		for (LoanTable loan: loanSet) {
			System.out.println(loan.getLoanId());
			System.out.println(loan.getMaxLoan());
			System.out.println(loan.getInterestRate());
			System.out.println(loan.getTenure());
			System.out.println(loan.getVehicletable().getVehicleid());
			System.out.println("-----------------");
		}
	}
	
	
}
