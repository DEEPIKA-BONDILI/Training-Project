package com.example.demo1;


import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo1.layer2.IncomeTable;
import com.example.demo1.layer2.UserTable;
import com.example.demo1.layer3.IncomeTableRepo;
import com.example.demo1.layer3.UserTableRepo;

@SpringBootTest
public class IncomeTableTestCases {

	@Autowired
	IncomeTableRepo incomeRepo;
@Autowired
UserTableRepo userRepo;
	@Test
	public void testIncomeInsert() {//successful 
	IncomeTable income=new IncomeTable();
	
		income.setTypeOfEmp("SALARIED");
		income.setOrganizationType("g");
		income.setEmployerName("krishna");
		incomeRepo.addIncome(income);
			
	}


	
	@Test
	public void testIncomedelete() {//successful
	
	incomeRepo.removeIncome(145);
			
	}

	
	@Test
	public void testIncomeModify() {//creating another row
	IncomeTable income=new IncomeTable();
	UserTable user=userRepo.findUser(163);
	Set<IncomeTable> myincs=user.getIncomeTables();
	if(myincs!=null) {
		for (IncomeTable incomeTable : myincs) {
			

	incomeTable.setTypeOfEmp("UNEMPLOYED");
	income.setOrganizationType("KL");
	income.setEmployerName("PaVan");
	
		}userRepo.modifyUser(user);	
	//incomeRepo.modifyIncome(income);
	
	}}
	
	
	
	
	@Test
	public void testIncomefind() {//successful
	IncomeTable income=incomeRepo.findIncome(203);
	System.out.println(income.getIncomeId());
	System.out.println(income.getTypeOfEmp());
	System.out.println(income.getOrganizationType());
	System.out.println(income.getUserTable());
	
	}
	
	
	
	@Test
	public void testIncomefindAll() { //successful
		Set<IncomeTable> incomeList=incomeRepo.findIncomes();		
		for(IncomeTable income:incomeList) {
		System.out.println(income.getIncomeId());
		System.out.println(income.getTypeOfEmp());
		System.out.println(income.getOrganizationType());
		System.out.println(income.getUserTable());
		
		
		}
	}
	
}

