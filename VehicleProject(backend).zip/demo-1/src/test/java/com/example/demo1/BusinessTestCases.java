package com.example.demo1;


import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo1.layer2.DocTable;
import com.example.demo1.layer2.IncomeTable;
import com.example.demo1.layer2.LoantrackerTable;
import com.example.demo1.layer2.Vehicletable;
import com.example.demo1.layer3.DocTableRepo;
import com.example.demo1.layer3.IncomeTableRepo;
import com.example.demo1.layer3.LoanTrackerTableRepo;
import com.example.demo1.layer3.VehicleTableRepo;


@SpringBootTest
public class BusinessTestCases {
	@Autowired
	DocTableRepo docRepo;
	@Autowired
	LoanTrackerTableRepo loanTrckrRepo;
	@Autowired
	IncomeTableRepo incomeRepo;
	@Autowired
	VehicleTableRepo vehicleRepo;
	@Test
	void DocByUserId() {//successful
		Set<DocTable> docSet = docRepo.findDocumentByUserId(101);
		for (DocTable doc: docSet) {
			System.out.println(doc.getDocId());
			System.out.println(doc.getPanCard());
			System.out.println(doc.getAdhaarCard());
			System.out.println(doc.getSalaryslip());
			System.out.println("-----------------");
		}
	}
		@Test
		void LoanTrackerByUserId() {//successful
			Set<LoantrackerTable> loanSet = loanTrckrRepo.findLoanAppIdByUserId(101);
			for (LoantrackerTable loan: loanSet) {
				System.out.println(loan.getFinalId());
				System.out.println(loan.getAccNo());
				System.out.println(loan.getLoanappId());
				System.out.println(loan.getLoanApprovalDate());
				System.out.println("-----------------");
			}
		}
		@Test
		void IncomeByUserId() {//successful
			Set<IncomeTable> incomeSet = incomeRepo.findIncomeByUserId(101);
			for (IncomeTable income: incomeSet) {
				System.out.println(income.getIncomeId());
				System.out.println(income.getTypeOfEmp());
				System.out.println(income.getOrganizationType());
				System.out.println(income.getUserTable());
				System.out.println("-----------------");
			}
		}
		@Test
		void VehicleByUserId() {//successful
			Set<Vehicletable> vehicleSet = vehicleRepo.findVehicleByUserId(101);
			for (Vehicletable vehicle: vehicleSet) {
				  System.out.println(vehicle.getVehicleid());
				  System.out.println(vehicle.getCompany());
				  System.out.println(vehicle.getModel());
				  System.out.println(vehicle.getColor());
				  System.out.println(vehicle.getVariant());
				  System.out.println(vehicle.getIncomeTable());
		
				  System.out.println("-----------------");
			}
		}
		
		
		
		
		
}