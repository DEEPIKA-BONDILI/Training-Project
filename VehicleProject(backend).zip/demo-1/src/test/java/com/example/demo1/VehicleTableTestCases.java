package com.example.demo1;


import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo1.layer2.IncomeTable;
import com.example.demo1.layer2.Vehicletable;
import com.example.demo1.layer3.IncomeTableRepo;
import com.example.demo1.layer3.VehicleTableRepo;

@SpringBootTest
public class VehicleTableTestCases {
	@Autowired
	VehicleTableRepo vehicleRepo;
	@Autowired
	IncomeTableRepo incRepo;
	@Test
	public void testInsertNewPro() {
		Vehicletable vehicle = new Vehicletable();
		
		vehicle.setCompany("HONDA");
		vehicle.setModel("CRV");
		vehicle.setColor("RED");
		vehicle.setVariant("ZXI");
		vehicle.setExshowroomprice(1000000);
                vehicle.setOnroadprice(1050000);
		
		
		vehicleRepo.addVehicle(vehicle);
	}
	@Test
	public void testModifyVehicle() {
		//Vehicletable vehicle = new Vehicletable();
		IncomeTable inc=incRepo.findIncome(182);
		Set<Vehicletable>vehicles=inc.getVehicletables();
		if(vehicles!=null) {
		for (Vehicletable vehicletable : vehicles) {
		
		vehicletable.setCompany("HONDA");
		vehicletable.setModel("CRV");
		vehicletable.setColor("RED");
		vehicletable.setVariant("ZXI");
		vehicletable.setExshowroomprice(1000000);
                vehicletable.setOnroadprice(1050000);
		
		}
		incRepo.modifyIncome(inc);
		}
	}
	@Test
	public void testRemoveVehicle() {
		vehicleRepo.removeVehicle(601);
		
	}
	@Test
	public void testFindVehicle() {
		Vehicletable vehicle = new Vehicletable();
		
                System.out.println(vehicle.getVehicleid());
		System.out.println(vehicle.getCompany());
		System.out.println(vehicle.getModel());
		System.out.println(vehicle.getColor());
		System.out.println(vehicle.getVariant());
		System.out.println(vehicle.getIncomeTable());
		
		System.out.println("-----------------");
	}
	@Test
	public void testFindAllPro() { 
		Set<Vehicletable> prolist = vehicleRepo.findVehicles();
		for (Vehicletable p: prolist) {
		System.out.println(p.getVehicleid());
		System.out.println(p.getCompany());
		System.out.println(p.getModel());
		System.out.println(p.getColor());
		System.out.println(p.getVariant());
		System.out.println(p.getIncomeTable());
		
			System.out.println("-----------------");
		}
	}

}
