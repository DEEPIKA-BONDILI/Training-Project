package com.example.demo1;


import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo1.layer2.DocTable;
import com.example.demo1.layer2.UserTable;
import com.example.demo1.layer3.DocTableRepo;
import com.example.demo1.layer3.UserTableRepo;

@SpringBootTest
public class DocTableTestCases {


	@Autowired
	DocTableRepo docRepo;
	@Autowired
	UserTableRepo userRepo;

	
	@Test
	public void testInsertNewDoc() {//successful
		DocTable doc = new DocTable();
		
		doc.setPanCard("Uploaded");
		doc.setSalaryslip("Uploaded");
		doc.setAdhaarCard("Uploaded");
UserTable user=userRepo.findUser(163);
doc.setUserTable(user);
		docRepo.addDocument(doc);
	}
	@Test
	public void testModifyDoc() {//creating new row
		/*DocTable doc = new DocTable();
		doc.setPanCard("Uploaded");
		doc.setSalaryslip("Uploaded");
		doc.setAdhaarCard("not uploaded");*/
		UserTable user=userRepo.findUser(163);
		Set <DocTable> myDocs = user.getDocTables(); // myDocs is attached to user
		if(myDocs!=null) {
		for (DocTable docTable : myDocs) {
			System.out.println("adhaar card : "+docTable.getAdhaarCard());
			docTable.setAdhaarCard("UPLOADED");
			docTable.setPanCard("NOT UPLOADED");
			docTable.setSalaryslip("Not uploaded");
		}
		userRepo.modifyUser(user);
		}


//		docRepo.modifyDocument(doc);
		
	}
	@Test
	public void testRemoveDoc() {//successful
		docRepo.removeDocument(143);
		
	}
	@Test
	public void testFindDoc() {//successful
		DocTable d=docRepo.findDocument(703);
		System.out.println(d.getDocId());
		System.out.println(d.getPanCard());
		System.out.println(d.getAdhaarCard());
		System.out.println(d.getSalaryslip());
		System.out.println("-----------------");
	
	}
	@Test
	public void testFindAllDoc() {//successful
		Set<DocTable> docList = docRepo.findDocuments();
		for (DocTable doc: docList) {
			System.out.println(doc.getDocId());
			System.out.println(doc.getPanCard());
			System.out.println(doc.getAdhaarCard());
			System.out.println(doc.getSalaryslip());
			System.out.println("-----------------");
		}
		
	}
}
