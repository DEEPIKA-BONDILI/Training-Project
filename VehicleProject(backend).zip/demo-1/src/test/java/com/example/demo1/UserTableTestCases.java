package com.example.demo1;

import java.sql.Date;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo1.layer2.UserTable;
import com.example.demo1.layer3.UserTableRepo;

@SpringBootTest
 class UserTableTestCases {
	
	@Autowired
	UserTableRepo userRepo;
	
	@Test
	public void testInsertNewUser() {//successful 
		UserTable user = new UserTable();
		
		user.setFname("gopi");
		user.setMname("krishna");
		user.setLname("g");
		user.setMailid("g@gmail.com");
		user.setPassword("123@asg");
		user.setConfirmPassword("123@asg");
		user.setAddress("ap");
		user.setPhoneno( 825412639);
		 String str="1996-08-15";
		 Date date=Date.valueOf(str);
		user.setDob(date);
		user.setGender("male");
		user.setNationality("indian");
		user.setAdharNo(12541269);
		user.setPanNo("clap1234");
		userRepo.addUser(user);
			
	}
	@Test
	public void testModify() {
		UserTable user = new UserTable();
		 user=userRepo.findUser(163);
		if(user!=null) {
			
		
		user.setFname("GOPI");
		user.setMname("KRISH");
		user.setLname("g");
		user.setMailid("g@gmail.com");
		user.setPassword("123@asg");
		user.setConfirmPassword("123@asg");
		user.setAddress("ka");
		user.setPhoneno( 825412639);
		 String str="1996-08-15";
		 Date date=Date.valueOf(str);
		user.setDob(date);
		user.setGender("male");
		user.setNationality("indian");
		user.setAdharNo(12541269);
		user.setPanNo("clap1234");

		userRepo.modifyUser(user);
		
		}
	}
	@Test
	public void testRemove() {//successful
		
		userRepo.removeUser(161);
		
		
		
	}
	@Test
	public void testUserFind() {//successful 

	   UserTable user=userRepo.findUser(105);
	        System.out.println(user.getUserId());
		System.out.println(user.getFname());
		System.out.println(user.getMname());
		System.out.println(user.getLname());
		System.out.println(user.getMailid());
		System.out.println(user.getPassword());
		System.out.println(user.getConfirmPassword());
		System.out.println(user.getAddress());
		System.out.println(user.getDob());
		System.out.println(user.getGender());
		System.out.println(user.getPhoneno());
		System.out.println(user.getNationality());
		System.out.println(user.getAdharNo());
		System.out.println(user.getPanNo());
		System.out.println("-----------------");

	}
	@Test
	public void testFindAll() {//
		Set<UserTable> userlist = userRepo.findUsers();
		for (UserTable user: userlist) {
			System.out.println(user.getUserId());
		System.out.println(user.getFname());
		System.out.println(user.getMname());
		System.out.println(user.getLname());
		System.out.println(user.getMailid());
		System.out.println(user.getPassword());
		System.out.println(user.getConfirmPassword());
		System.out.println(user.getAddress());
		System.out.println(user.getDob());
		System.out.println(user.getGender());
		System.out.println(user.getPhoneno());
		System.out.println(user.getNationality());
		System.out.println(user.getAdharNo());
		System.out.println(user.getPanNo());
		System.out.println("-----------------");
	}
	
	}
}

