package com.example.demo1;

import java.sql.Date;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo1.layer2.DocTable;
import com.example.demo1.layer2.LoantrackerTable;
import com.example.demo1.layer3.DocTableRepo;
import com.example.demo1.layer3.LoanTrackerTableRepo;

@SpringBootTest
public class LoanTrackerTableTestCases {
	@Autowired
	LoanTrackerTableRepo loantrackerRepo;
	@Autowired
	DocTableRepo docRepo;
	
	@Test
	public void testLoantrackerTableInsert() {//successful
	LoantrackerTable loanTracker=new LoantrackerTable();
	String str2="2021-08-15";
	Date date2=Date.valueOf(str2);
	loanTracker.setLoanApprovalDate(date2);
	loanTracker.setAccNo(1524789365);
	loanTracker.setLoanappId(10006);
	DocTable doc=docRepo.findDocument(141); 
	loanTracker.setDocTable(doc);
	loantrackerRepo.addLoantrackerDetails(loanTracker);
	
	}
	
	@Test
	public void testLoantrackerTableDelete() {//successful
		loantrackerRepo.removeLoantrackerDetails(148);
	}
	@Test
	public void testLoantrackerTableModify() {
	LoantrackerTable loanTracker=new LoantrackerTable();
	DocTable doc=docRepo.findDocument(704);  
	loantrackerRepo.findLoantrackerDetails(803); 
	loanTracker.setFinalId(803);
	String str2="1996-08-15";
	 Date date2=Date.valueOf(str2);
	loanTracker.setLoanApprovalDate(date2);
	loanTracker.setLoanappId(10005);
	loanTracker.setAccNo(952147823);
	loanTracker.setDocTable(doc);
	loantrackerRepo.modifyLoantrackerDetails(loanTracker);
	}
	
	@Test
	public void testLoantrackerTableFindAll() {//successful
	Set<LoantrackerTable> lSet=loantrackerRepo.findAllLoantrackerDetails();		
	for(LoantrackerTable loanTracker:lSet) {
		System.out.println(loanTracker.getAccNo());
		System.out.println(loanTracker.getFinalId());
		System.out.println(loanTracker.getLoanappId());
		System.out.println(loanTracker.getLoanApprovalDate());
		System.out.println(loanTracker.getDocTable().getDocId());
		
	}
	}
	
	@Test
	public void testLoanTrackerFind() {//successful
		LoantrackerTable loanTracker=loantrackerRepo.findLoantrackerDetails(802);
		System.out.println(loanTracker.getLoanApprovalDate());
		System.out.println(loanTracker.getLoanappId());
		System.out.println(loanTracker.getAccNo());
		System.out.println(loanTracker.getDocTable().getDocId());
		
		
		System.out.println("-----------------");
	}
	
}

