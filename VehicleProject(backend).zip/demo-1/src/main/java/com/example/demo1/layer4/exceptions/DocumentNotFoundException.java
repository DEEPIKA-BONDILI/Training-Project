package com.example.demo1.layer4.exceptions;



@SuppressWarnings("serial")
public class DocumentNotFoundException extends Exception {

	public DocumentNotFoundException(String message) {
		super(message);
		System.out.println("Document not found......");	}
}