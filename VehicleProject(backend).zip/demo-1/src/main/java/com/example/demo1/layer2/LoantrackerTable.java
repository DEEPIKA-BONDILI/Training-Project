package com.example.demo1.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Date;


/**
 * The persistent class for the LOANTRACKER_TABLE database table.
 * 
 */
@Entity
@Table(name="LOANTRACKER_TABLE")
@NamedQuery(name="LoantrackerTable.findAll", query="SELECT l FROM LoantrackerTable l")
public class LoantrackerTable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="FINAL_ID")
	private int finalId;

	@Column(name="ACC_NO")
	private double accNo;

	@Temporal(TemporalType.DATE)
	@Column(name="LOAN_APPROVAL_DATE")
	private Date loanApprovalDate;

	@Column(name="LOANAPP_ID")
	private int loanappId;

	//bi-directional many-to-one association to DocTable
	@ManyToOne
	@JoinColumn(name="DOC_ID")
	private DocTable docTable;

	public LoantrackerTable() {
	}

	public int getFinalId() {
		return this.finalId;
	}

	public void setFinalId(int finalId) {
		this.finalId = finalId;
	}

	public double getAccNo() {
		return this.accNo;
	}

	public void setAccNo(double accNo) {
		this.accNo = accNo;
	}

	public Date getLoanApprovalDate() {
		return this.loanApprovalDate;
	}

	public void setLoanApprovalDate(Date loanApprovalDate) {
		this.loanApprovalDate = loanApprovalDate;
	}

	public int getLoanappId() {
		return this.loanappId;
	}

	public void setLoanappId(int loanappId) {
		this.loanappId = loanappId;
	}
	@JsonIgnore
	public DocTable getDocTable() {
		return this.docTable;
	}

	public void setDocTable(DocTable docTable) {
		this.docTable = docTable;
	}

}