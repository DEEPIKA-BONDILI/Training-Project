package com.example.demo1.layer3;

import java.util.HashSet;

import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo1.layer2.Vehicletable;
@Repository
public class VehicleTableRepoImpl implements VehicleTableRepo {
	@PersistenceContext
	 EntityManager entityManager;
	
	@Transactional
	public void addVehicle(Vehicletable vRef) {
		entityManager.persist(vRef);

	}
	@Transactional
	public Vehicletable findVehicle(int vno) {
		System.out.println("Vehicle repo....NO scope of bussiness logic here...");
		return entityManager.find(Vehicletable.class,vno);
		
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Transactional
	public Set<Vehicletable> findVehicles() {
		Set<Vehicletable> vehSet;
		vehSet = new HashSet<Vehicletable>();
		String queryString = "from Vehicletable";
		Query query = entityManager.createQuery(queryString);
		vehSet = new HashSet(query.getResultList());
		return vehSet;
	}
	@Transactional
	public void modifyVehicle(Vehicletable vRef) {
		entityManager.merge(vRef);

	}
	@Transactional
	public void removeVehicle(int vno) {
		Vehicletable vTemp = entityManager.find(Vehicletable.class,vno);
		entityManager.remove(vTemp);
			
		
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Transactional
	public Set<Vehicletable> findVehicleByUserId(int v) 
	{
			Set<Vehicletable> docSet;		
			Query query = entityManager.createNativeQuery("select * from vehicletable where income_id=(select income_id from income_table where user_id=101)",Vehicletable.class);
			docSet = new HashSet(query.getResultList());
			return docSet;
	}
}
