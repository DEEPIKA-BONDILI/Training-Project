package com.example.demo1.layer3;


import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo1.layer2.IncomeTable;

@Repository
public class IncomeTableRepoImpl implements IncomeTableRepo {

@PersistenceContext
EntityManager entityManager;

@Transactional
public void addIncome(IncomeTable iRef) {
entityManager.persist(iRef);

}
@Transactional
public IncomeTable findIncome(int ino) {
System.out.println("IncomeTable repo....NO scope of bussiness logic here...");
return entityManager.find(IncomeTable.class,ino);

}
@SuppressWarnings({ "rawtypes", "unchecked" })
@Transactional
public Set<IncomeTable> findIncomes()
{
Set<IncomeTable> incomeSet;
incomeSet = new HashSet<IncomeTable>();
String queryString = "from IncomeTable";
Query query = entityManager.createQuery(queryString);
incomeSet = new HashSet(query.getResultList());
return incomeSet;
}

@Transactional
public void modifyIncome(IncomeTable iRef)
{
entityManager.merge(iRef);

}

@Transactional
public void removeIncome(int ino)
{

IncomeTable iTemp = entityManager.find(IncomeTable.class,ino);
entityManager.remove(iTemp);
}
@SuppressWarnings({ "rawtypes", "unchecked" })
@Transactional
public Set<IncomeTable> findIncomeByUserId(int i) {
	Set<IncomeTable> incomeSet;
	Query query = entityManager.createQuery("from IncomeTable e where user_id =:myno",IncomeTable.class).setParameter("myno", i);
	incomeSet = new HashSet(query.getResultList());
	
return incomeSet;
}
}


