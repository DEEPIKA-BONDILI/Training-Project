package com.example.demo1.layer5;

import java.util.HashMap;

import java.util.Map;
import java.util.Set;

//import org.springframework.web.bind.annotation.*;
//import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo1.layer2.LoanTable;
import com.example.demo1.layer2.Vehicletable;
import com.example.demo1.layer2.dto.LoanTableDTO;
import com.example.demo1.layer3.VehicleTableRepo;
import com.example.demo1.layer4.LoanTableService;
import com.example.demo1.layer4.exceptions.LoanAlreadyExistException;
import com.example.demo1.layer4.exceptions.LoanNotFoundException;

@CrossOrigin(origins="http://localhost:4200")
@RestController  //REpresentational State Transfer html xml json
public class LoanTableController {

	@Autowired
	LoanTableService loanServ;
	@Autowired
	VehicleTableRepo vehicleRepo;
	
	@GetMapping(path="/getLoan/{mylno}") //Get Request in Postman http://localhost:8080/getLoan/1
	@ResponseBody
	public ResponseEntity<LoanTable> getLoan(@PathVariable("mylno") Integer lno) throws LoanNotFoundException  {
		System.out.println("LoanTable Controller....Understanding client and talking to service layer...");
		LoanTable loan = null;
			loan =loanServ.findLoanService(lno);
			if(loan == null) {
				Map m = new HashMap();
				m.put("message",  "Loan Not found");
				//HeadersBuilder hb = ResponseEntity.notFound();
				
				HttpStatus status =HttpStatus.NOT_FOUND;
				//return new ResponseEntity(m,status);
				return ResponseEntity.notFound().build();
				//return new 
				
			}
			else {
				return ResponseEntity.ok(loan);
			}
	}
	
	
	@GetMapping(path="/getLoans")
	@ResponseBody
	public Set<LoanTable> getAllLoans() {
		System.out.println("LoanTable Controller....Understanding client and talking to service layer...");
		Set<LoanTable> loanList = loanServ.findAllLoansService();
		return loanList;
		
	}
	
	@PostMapping(path="/addLoan")
	public String addLoan(@RequestBody LoanTableDTO loanDTO) {
//		LoanTable loan1 =new LoanTable();
//		loan1.setInterestRate(loan.getInterestRate());
//		loan1.setLoanAmount(loan.getLoanAmount());
//		loan1.setLoanId(loan.getLoanId());
//		loan1.setMaxLoan(loan.getMaxLoan());
//		loan1.setTenure(loan.getTenure());
//		Vehicletable vehicle=vehicleRepo.findVehicle(601);
//		loan1.setVehicletable(vehicle);
//		
		String statusMsg = null;
		try {
			statusMsg =loanServ.addLoanService(loanDTO);
		} catch (LoanAlreadyExistException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return statusMsg;
		
	}
	
	@PutMapping(path="/modifyLoan")
	public String modifyLoan(@RequestBody LoanTable loan) {
		String statusMsg = null;
		try {
			statusMsg = loanServ.modifyLoanService(loan);
		} catch (LoanNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			return e.getMessage();
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return statusMsg;
		
	}
	
 	@DeleteMapping(path="/deleteLoan")
	public String deleteLoan(@RequestBody LoanTable loan) {
		String statusMsg = null;
		try {
			statusMsg = loanServ.removeLoanService(loan.getLoanId());
		} catch (LoanNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			return e.getMessage();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return statusMsg;
		
	}
	
}