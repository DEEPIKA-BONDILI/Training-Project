package com.example.demo1.layer4;

import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo1.layer2.IncomeTable;
import com.example.demo1.layer2.UserTable;
import com.example.demo1.layer2.dto.IncomeTableDTO;
import com.example.demo1.layer3.IncomeTableRepo;
import com.example.demo1.layer3.UserTableRepo;
import com.example.demo1.layer4.exceptions.IncomeAlreadyExistException;
import com.example.demo1.layer4.exceptions.IncomeNotFoundException;

@Service
public class IncomeTableServiceImpl implements IncomeTableService {
		
	@Autowired
	IncomeTableRepo incomeRepo;
	
	@Autowired
	UserTableRepo userRepo;
	
	@Override
	public IncomeTable findIncomeService(int dno) throws IncomeNotFoundException {
		System.out.println("Income Service....Some scope of bussiness logic here...");
		return incomeRepo.findIncome(dno);
	}
	
	@Override
	public String removeIncomeService(int dno) throws IncomeNotFoundException {
		IncomeTable d =incomeRepo.findIncome(dno);
		if(d!=null)
		{incomeRepo.removeIncome(d.getIncomeId());}
		else {
			throw new IncomeNotFoundException("IncomeRow Not Found");
		}
		return "IncomeRow Deleted successfully";
	}

	@Override
	public String addIncomeService(IncomeTableDTO inc) throws IncomeAlreadyExistException {
		System.out.println("Income Service....Some scope of bussiness logic here...");
		try {
			IncomeTable income = new IncomeTable();
			income.setIncomeId(inc.getIncomeId());
			income.setTypeOfEmp(inc.getTypeOfEmp());
			income.setOrganizationType(inc.getOrganizationType());
			income.setEmployerName(inc.getEmployerName());
			UserTable user = userRepo.findUser(inc.getUserId());
//			user.getIncomeTables().add(income);
			income.setUserTable(user);
			//userRepo.modifyUser(user);
			incomeRepo.addIncome(income);
		}
		catch (Exception e) {
			throw new IncomeAlreadyExistException("Income already exists");	
		}
		return "IncomeRow added successfully";
	}

	@Override
	public String modifyIncomeService(IncomeTableDTO dRef) throws IncomeNotFoundException {
		System.out.println("Income Service....Some scope of bussiness logic here...");
		
		//IncomeTable it = incomeRepo.findIncome(dRef.getIncomeId());
		System.out.println(dRef.getIncomeId());
		System.out.println(dRef.getTypeOfEmp());
		UserTable user = userRepo.findUser(dRef.getUserId()); // userid from DTO <-> DTO got it from postman --> same way inside angular DTO and then to angular html
		Set <IncomeTable> incomeSet = user.getIncomeTables();
		if(incomeSet!=null) {
			for (IncomeTable incomeTable : incomeSet) {
				System.out.println(incomeTable.getIncomeId());
				System.out.println(incomeTable.getTypeOfEmp());
				if(incomeTable.getIncomeId()== dRef.getIncomeId())
				{
				//	incomeTable = it;
					incomeTable.setTypeOfEmp(dRef.getTypeOfEmp());
					//incomeTAble.set
				}
				//incomeTable.setTypeOfEmp(dRef.getTypeOfEmp());
				//incomeTable.
			}
		}
		userRepo.modifyUser(user);
		/*
		//IncomeTable d =incomeRepo.findIncome(dRef.getIncomeId());
		if(d!=null)
		{incomeRepo.modifyIncome(dRef);}
		else {
			throw new IncomeNotFoundException("IncomeRow Not Found");
		}*/
		return "IncomeRow modified successfully";
	}

	@Override
	public Set<IncomeTable> findIncomesService() {
		System.out.println("Income Service....Some scope of bussiness logic here...");
		return incomeRepo.findIncomes();
	}

}
