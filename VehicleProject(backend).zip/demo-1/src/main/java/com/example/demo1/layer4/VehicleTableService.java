package com.example.demo1.layer4;

import java.util.Set;

import com.example.demo1.layer2.Vehicletable;
import com.example.demo1.layer2.dto.VehicletableDTO;
import com.example.demo1.layer4.exceptions.VehicleAlreadyExistException;
import com.example.demo1.layer4.exceptions.VehicleNotFoundException;


 public interface VehicleTableService {
	    String addVehicleService(VehicletableDTO vDTO) throws VehicleAlreadyExistException;  //C - add/create;
		Vehicletable findVehicleService(int vno) throws VehicleNotFoundException ;			//  R - find - select					
		String modifyVehicleService(Vehicletable vRef)throws VehicleNotFoundException;		//  U - modify - update
		String removeVehicleService(int vno) throws VehicleNotFoundException;
		Set<Vehicletable> findVehicleService();
		
}
