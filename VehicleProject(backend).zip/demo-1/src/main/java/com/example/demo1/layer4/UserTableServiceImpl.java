package com.example.demo1.layer4;

import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo1.layer2.UserTable;
import com.example.demo1.layer2.dto.LoginDTO;
import com.example.demo1.layer3.UserTableRepo;
import com.example.demo1.layer4.exceptions.UserAlreadyExistException;
import com.example.demo1.layer4.exceptions.UserNotFoundException;

@Service
public class UserTableServiceImpl implements UserTableService {

	@Autowired
	UserTableRepo userRepo;
	
	@Override
		public String addUserService(UserTable uRef) throws UserAlreadyExistException {
			System.out.println("User Service....Some scope of bussiness logic here...");
			try {
				userRepo.addUser(uRef);
				
			} catch (Exception e) {
				
				throw new UserAlreadyExistException("User Already Exist");
			}
			return "User added successfully";

			}
	
	@Override
	public UserTable findUserService(LoginDTO logUser)throws UserNotFoundException  {
		boolean found=false;
		
		System.out.println("User Service....Some scope of bussiness logic here...");
		UserTable user = userRepo.findUser(logUser.getUserId());
		if(user == null) {
			throw new UserNotFoundException("User Not Found");
		}
		if(user.getPassword().equals(logUser.getPassword()))
			found=true;
		
		if(found)
			return user;
		else 
			throw new UserNotFoundException("User password invalid");
		
		
	}
	
	@Override
	public UserTable findUserService(int userId)throws UserNotFoundException  {
		boolean found=false;
		
		System.out.println("User Service....Some scope of bussiness logic here...");
		UserTable user = userRepo.findUser(userId);
		if(user == null) {
			throw new UserNotFoundException("User Not Found");
		}
		
		if(found)
			return user;
		
		return user;
	}
	@Override
	public String modifyUserService(UserTable uRef) throws UserNotFoundException {
		UserTable user = userRepo.findUser(uRef.getUserId());
		if(user == null) {
			throw new UserNotFoundException("User Not Found");	
		}
		else {
			userRepo.modifyUser(uRef);
		}
		return "User modifed successfully";
	}
	@Override
	public String removeUserService(int uno) throws UserNotFoundException  {	
		UserTable user = userRepo.findUser(uno);
		if(user == null) {
		throw new UserNotFoundException("User Not Found");
		}
		else {
		userRepo.removeUser(uno);
		}		
		return "User Deleted successfully";
		}

	@Override
	public Set<UserTable> findUsersService() {
		System.out.println("User Service....Some scope of bussiness logic here...");
		return userRepo.findUsers();
	}

}
