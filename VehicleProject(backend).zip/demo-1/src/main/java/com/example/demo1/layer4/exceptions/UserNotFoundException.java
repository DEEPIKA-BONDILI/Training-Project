package com.example.demo1.layer4.exceptions;

@SuppressWarnings("serial")
public class UserNotFoundException extends Exception {

	public UserNotFoundException(String message) 
	{
		super(message);
		System.out.println("User Not Found......................");
	}
}

