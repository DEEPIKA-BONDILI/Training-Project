package com.example.demo1.layer4.exceptions;

@SuppressWarnings("serial")
public class IncomeAlreadyExistException extends Exception{

	public IncomeAlreadyExistException(String message)
	{
		super(message);
		System.out.println("Income Alreay Exist..........");
	}
}


