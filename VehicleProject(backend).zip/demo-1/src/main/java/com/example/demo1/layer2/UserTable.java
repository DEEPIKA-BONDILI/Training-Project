package com.example.demo1.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;


/**
 * The persistent class for the USER_TABLE database table.
 * 
 */
@Entity
@Table(name="USER_TABLE")
@NamedQuery(name="UserTable.findAll", query="SELECT u FROM UserTable u")
public class UserTable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="USER_ID")
	private int userId;

	private String address;

	@Column(name="ADHAR_NO")
	private long adharNo;

	@Column(name="CONFIRM_PASSWORD")
	private String confirmPassword;

	@Temporal(TemporalType.DATE)
	private Date dob;

	private String fname;

	private String gender;

	private String lname;

	private String mailid;

	private String mname;

	private String nationality;

	@Column(name="PAN_NO")
	private String panNo;

	private String password;

	private long phoneno;

	//bi-directional many-to-one association to DocTable
	@OneToMany(mappedBy="userTable", fetch=FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<DocTable> docTables=new HashSet<DocTable>();

	//bi-directional many-to-one association to IncomeTable
	@OneToMany(mappedBy="userTable", fetch=FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<IncomeTable> incomeTables=new HashSet<IncomeTable>();

	public UserTable() {
	}

	public int getUserId() {
		return this.userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getAdharNo() {
		return this.adharNo;
	}

	public void setAdharNo(long adharNo) {
		this.adharNo = adharNo;
	}

	public String getConfirmPassword() {
		return this.confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getFname() {
		return this.fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLname() {
		return this.lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getMailid() {
		return this.mailid;
	}

	public void setMailid(String mailid) {
		this.mailid = mailid;
	}

	public String getMname() {
		return this.mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getNationality() {
		return this.nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getPanNo() {
		return this.panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getPhoneno() {
		return this.phoneno;
	}

	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}

	public Set<DocTable> getDocTables() {
		return this.docTables;
	}

	public void setDocTables(Set<DocTable> docTables) {
		this.docTables = docTables;
	}

	public DocTable addDocTable(DocTable docTable) {
		getDocTables().add(docTable);
		docTable.setUserTable(this);

		return docTable;
	}

	public DocTable removeDocTable(DocTable docTable) {
		getDocTables().remove(docTable);
		docTable.setUserTable(null);

		return docTable;
	}

	public Set<IncomeTable> getIncomeTables() {
		return this.incomeTables;
	}

	public void setIncomeTables(Set<IncomeTable> incomeTables) {
		this.incomeTables = incomeTables;
	}

	public IncomeTable addIncomeTable(IncomeTable incomeTable) {
		getIncomeTables().add(incomeTable);
		incomeTable.setUserTable(this);

		return incomeTable;
	}

	public IncomeTable removeIncomeTable(IncomeTable incomeTable) {
		getIncomeTables().remove(incomeTable);
		incomeTable.setUserTable(null);

		return incomeTable;
	}

}