package com.example.demo1.layer2.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

public class LoantrackerTableDTO {

	private int finalId;
	private double accNo;
	private Date loanApprovalDate;
	private int loanappId;
	private int docId;
	public int getFinalId() {
		return finalId;
	}
	public void setFinalId(int finalId) {
		this.finalId = finalId;
	}
	public double getAccNo() {
		return accNo;
	}
	public void setAccNo(double accNo) {
		this.accNo = accNo;
	}
	public Date getLoanApprovalDate() {
		return loanApprovalDate;
	}
	public void setLoanApprovalDate(Date loanApprovalDate) {
		this.loanApprovalDate = loanApprovalDate;
	}
	public int getLoanappId() {
		return loanappId;
	}
	public void setLoanappId(int loanappId) {
		this.loanappId = loanappId;
	}
	public int getDocId() {
		return docId;
	}
	public void setDocId(int docId) {
		this.docId = docId;
	}
	
}
