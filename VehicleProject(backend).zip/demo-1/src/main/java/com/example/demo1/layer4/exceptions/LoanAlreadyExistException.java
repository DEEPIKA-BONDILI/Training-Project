package com.example.demo1.layer4.exceptions;


@SuppressWarnings("serial")
public class LoanAlreadyExistException extends Exception{

	public LoanAlreadyExistException(String message)
	{
		super(message);
		System.out.println("Loan Already Exist.....");
	}
}

