package com.example.demo1.layer3;

import java.util.*;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.example.demo1.layer2.LoantrackerTable;



@Repository
public class LoanTrackerTableRepoImpl implements LoanTrackerTableRepo {

@PersistenceContext
	 EntityManager entityManager;
										
	
	@Transactional
	public void addLoantrackerDetails(LoantrackerTable ltRef) {
		entityManager.persist(ltRef);

	}
	
	@Transactional
	public LoantrackerTable findLoantrackerDetails(int ltno) {
		System.out.println("LoantrackerTable Repository....NO scope of bussiness logic here...");
		return entityManager.find(LoantrackerTable.class,ltno);
		
	}
        
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional
	public Set<LoantrackerTable> findAllLoantrackerDetails()
	{
	Set<LoantrackerTable> loantrackerSet;
	loantrackerSet = new HashSet<LoantrackerTable>();
	String queryString = "from LoantrackerTable";
	Query query = entityManager.createQuery(queryString);
	loantrackerSet = new HashSet(query.getResultList());
	return loantrackerSet;
	}
	
	@Transactional
	public void modifyLoantrackerDetails(LoantrackerTable ltRef) {
		entityManager.merge(ltRef);

	}

	@Transactional
	public void removeLoantrackerDetails(int ltno) {
		LoantrackerTable dTemp = entityManager.find(LoantrackerTable.class,ltno);
		entityManager.remove(dTemp);
		
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional
	public Set<LoantrackerTable> findLoanAppIdByUserId(int i) 
	{
		Set<LoantrackerTable> loanSet;
		Query query = entityManager.createNativeQuery("select * from loantracker_table where doc_id=(select doc_id from doc_table where rep_id=101)",LoantrackerTable.class);
loanSet = new HashSet(query.getResultList());
		
		return loanSet;
	}
}
	

