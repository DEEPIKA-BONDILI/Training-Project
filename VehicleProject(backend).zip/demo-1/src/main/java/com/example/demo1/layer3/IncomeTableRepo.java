package com.example.demo1.layer3;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.example.demo1.layer2.IncomeTable;
@Repository
public interface IncomeTableRepo {
	void addIncome(IncomeTable iRef);
	void removeIncome(int ino);
	void modifyIncome(IncomeTable iRef);
	IncomeTable findIncome(int ino);
	Set<IncomeTable>findIncomes();
	Set<IncomeTable> findIncomeByUserId(int i);
	}

