package com.example.demo1.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo1.layer2.IncomeTable;
import com.example.demo1.layer2.UserTable;
import com.example.demo1.layer2.Vehicletable;
import com.example.demo1.layer2.dto.VehicletableDTO;
import com.example.demo1.layer3.IncomeTableRepo;
import com.example.demo1.layer3.UserTableRepo;
import com.example.demo1.layer3.VehicleTableRepo;
import com.example.demo1.layer4.exceptions.VehicleAlreadyExistException;
import com.example.demo1.layer4.exceptions.VehicleNotFoundException;

@Service
public class VehicleTableServiceImpl implements VehicleTableService 
{
		@Autowired	
		VehicleTableRepo vehicleRepo;
		
		@Autowired
		IncomeTableRepo incomeRepo;
		
		@Autowired
		UserTableRepo userRepo;
		
		@Override
		public String addVehicleService(VehicletableDTO vDTO) throws VehicleAlreadyExistException  {
			System.out.println("Vehicle Service....Some scope of bussiness logic here...");
			try {
				Vehicletable vehicle = new Vehicletable();
				vehicle.setVehicleid(vDTO.getVehicleid());
				vehicle.setColor(vDTO.getColor());
				vehicle.setCompany(vDTO.getCompany());
				vehicle.setModel(vDTO.getModel());
				vehicle.setExshowroomprice(vDTO.getExshowroomprice());
				vehicle.setOnroadprice(vDTO.getOnroadprice());
				vehicle.setVariant(vDTO.getVariant());
				IncomeTable income = incomeRepo.findIncome(vDTO.getIncomeId());
				vehicle.setIncomeTable(income);
//				UserTable user = userRepo.findUser(vDTO.getIncomeId());
//				if(income.getUserTable()==user)
//       			{
//					income.getVehicletables().add(vehicle);
//				    vehicle.setIncomeTable(income);
//					incomeRepo.modifyIncome(income);
//				}
				vehicleRepo.addVehicle(vehicle);
			} catch (Exception e) {
				throw new VehicleAlreadyExistException("Vehicle Already Exsist");
			}
			return "Vehicletable added successfully";
		}
		
		@Override
		public Vehicletable findVehicleService(int vno) throws VehicleNotFoundException {
			System.out.println("Vehicle Service....NO scope of bussiness logic here...");
			Vehicletable vehicle = vehicleRepo.findVehicle(vno);
			if(vehicle == null) {
				throw new VehicleNotFoundException("Vehicle Not Found");
			}
			return vehicle;
		}
			
		
	
		@Override
		public  String modifyVehicleService(Vehicletable vRef) throws 

VehicleNotFoundException{
			Vehicletable vehicle =vehicleRepo.findVehicle(vRef.getVehicleid());
			if( vehicle== null) {
				throw new VehicleNotFoundException("Vehicle Not Found");
				
			}
			else {
				vehicleRepo.modifyVehicle(vRef);
			}
				
				return "Vehicletable modified successfully";
	      }

	
		@Override
		public String removeVehicleService(int vno) throws VehicleNotFoundException {
			Vehicletable vehicle = vehicleRepo.findVehicle(vno);
			if(vehicle== null) {
				throw new VehicleNotFoundException("Vehicle Not Found");
				
			}
			else {
				vehicleRepo.removeVehicle(vno);
			}
				
		return "Vehicle Deleted successfully";
	
		}
		@Override
		public Set<Vehicletable> findVehicleService() {
			System.out.println("Vehicle Service....Some scope of bussiness logic here...");
			return vehicleRepo.findVehicles();
		}
		
		
		}

