package com.example.demo1.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.HashSet;
import java.util.Set;


/**
 * The persistent class for the DOC_TABLE database table.
 * 
 */
@Entity
@Table(name="DOC_TABLE")
@NamedQuery(name="DocTable.findAll", query="SELECT d FROM DocTable d")
public class DocTable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DOC_ID")
	private int docId;

	@Column(name="ADHAAR_CARD")
	private String adhaarCard;

	@Column(name="PAN_CARD")
	private String panCard;

	private String salaryslip;

	//bi-directional many-to-one association to UserTable
	@ManyToOne
	@JoinColumn(name="REP_ID")
	private UserTable userTable;

	//bi-directional many-to-one association to LoantrackerTable
	@OneToMany(mappedBy="docTable", fetch=FetchType.EAGER)
	private Set<LoantrackerTable> loantrackerTables=new HashSet<LoantrackerTable>();

	public DocTable() {
	}

	public int getDocId() {
		return this.docId;
	}

	public void setDocId(int docId) {
		this.docId = docId;
	}

	public String getAdhaarCard() {
		return this.adhaarCard;
	}

	public void setAdhaarCard(String adhaarCard) {
		this.adhaarCard = adhaarCard;
	}

	public String getPanCard() {
		return this.panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public String getSalaryslip() {
		return this.salaryslip;
	}

	public void setSalaryslip(String salaryslip) {
		this.salaryslip = salaryslip;
	}
	@JsonIgnore
	public UserTable getUserTable() {
		return this.userTable;
	}

	public void setUserTable(UserTable userTable) {
		this.userTable = userTable;
	}

	public Set<LoantrackerTable> getLoantrackerTables() {
		return this.loantrackerTables;
	}

	public void setLoantrackerTables(Set<LoantrackerTable> loantrackerTables) {
		this.loantrackerTables = loantrackerTables;
	}

	public LoantrackerTable addLoantrackerTable(LoantrackerTable loantrackerTable) {
		getLoantrackerTables().add(loantrackerTable);
		loantrackerTable.setDocTable(this);

		return loantrackerTable;
	}

	public LoantrackerTable removeLoantrackerTable(LoantrackerTable loantrackerTable) {
		getLoantrackerTables().remove(loantrackerTable);
		loantrackerTable.setDocTable(null);

		return loantrackerTable;
	}

}