package com.example.demo1.layer5;

import java.util.Set;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo1.layer2.DocTable;
import com.example.demo1.layer2.LoantrackerTable;
import com.example.demo1.layer2.dto.LoantrackerTableDTO;
import com.example.demo1.layer3.DocTableRepo;
import com.example.demo1.layer4.LoanTrackerTableService;
import com.example.demo1.layer4.exceptions.LoanTrackerAlreadyExistException;
import com.example.demo1.layer4.exceptions.LoanTrackerNotFoundException;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class LoanTrackerTableController {

	@Autowired
	LoanTrackerTableService loanTrackerServ;
	
	@Autowired
	DocTableRepo documentRepo;
	
	@GetMapping(path="/getLoanTracker/{mylno}")
	@ResponseBody
	public ResponseEntity<LoantrackerTable> getLoanTracker(@PathVariable("mylno") Integer lno) throws LoanTrackerNotFoundException {
		System.out.println("LoanTrackerTable Controller....Understanding client and talking to service layer...");
		LoantrackerTable loanTracker=null;
		
		loanTracker = loanTrackerServ.findLoanTrackerService(lno);
			if(loanTracker==null)
			{ 
				return ResponseEntity.notFound().build();
			
			}
			else {
				return ResponseEntity.ok(loanTracker);
			}
		
	}
	
	@GetMapping(path="/getLoanTrackers")
	@ResponseBody
	public Set<LoantrackerTable> getAllLoanTrackers() {
		System.out.println("LoanTrackerTable Controller....Understanding client and talking to service layer...");
		Set<LoantrackerTable> loantrackerSet = loanTrackerServ.findLoanTrackersService();
		
		return loantrackerSet;
		
	}

	@PostMapping(path="/addLoanTracker")
	public String addLoanTracker(@RequestBody LoantrackerTableDTO ltDTO) {
		System.out.println(" LoanTrackerTable Controller....Understanding client and talking to service layer...");
//		LoantrackerTable loan=new LoantrackerTable();
//		loan.setAccNo(loanTracker.getAccNo());
//		loan.setLoanApprovalDate(loanTracker.getLoanApprovalDate());
//		 DocTable document=documentRepo.findDocument(702);
//		 loan.setDocTable(document);
		String stmsg = null;
		try {
			stmsg = loanTrackerServ.addLoanTrackerService(ltDTO);
		} 
	 catch (LoanTrackerAlreadyExistException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		System.out.println("controller printing"+stmsg);
		  return stmsg;
		
	}
	@PutMapping(path="/modifyLoanTracker")
	public String modifyLoanTracker(@RequestBody LoantrackerTable loanTracker)throws LoanTrackerNotFoundException {
		System.out.println("LoanTrackerTable Controller....Understanding client and talking to service layer...");
		 String stmsg = null;
		try {
			stmsg = loanTrackerServ.modifyLoanTrackerService(loanTracker);
		} 
		catch (LoanTrackerNotFoundException e) {
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("controller is saying: "+stmsg);
		  return stmsg;
		
	}
	@DeleteMapping(path="/deleteLoanTracker")
	public String removeLoanTracker(@RequestBody LoantrackerTable loanTracker)throws LoanTrackerNotFoundException {
		System.out.println("LoanTrackerTable Controller....Understanding client and talking to service layer...");
		 String stmsg = null;
		try {
			stmsg = loanTrackerServ.removeLoanTrackerService(loanTracker.getFinalId());
		} 
		catch (LoanTrackerNotFoundException e) {
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("controller is saying: "+stmsg);
		  return stmsg;
		
	}
	


}