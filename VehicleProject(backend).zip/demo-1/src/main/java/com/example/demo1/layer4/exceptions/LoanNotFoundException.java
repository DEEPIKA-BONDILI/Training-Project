package com.example.demo1.layer4.exceptions;

@SuppressWarnings("serial")
public class LoanNotFoundException extends Exception {

	public LoanNotFoundException(String message) {
		super(message);
		System.out.println("Loan Not Found.....");
		
	}

}