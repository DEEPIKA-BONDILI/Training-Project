package com.example.demo1.layer4.exceptions;

@SuppressWarnings("serial")
public class DocumentAlreadyExistException extends Exception{
	public DocumentAlreadyExistException(String message) {
		super(message);
		System.out.println("Document already exists........");
	}
}


