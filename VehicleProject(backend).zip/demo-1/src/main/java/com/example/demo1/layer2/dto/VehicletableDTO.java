package com.example.demo1.layer2.dto;

public class VehicletableDTO {

	private int vehicleid;
	private String color;
	private String company;
	private long exshowroomprice;
	private String model;
	private long onroadprice;
	private String variant;
	private int incomeId;
	public int getVehicleid() {
		return vehicleid;
	}
	public void setVehicleid(int vehicleid) {
		this.vehicleid = vehicleid;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public long getExshowroomprice() {
		return exshowroomprice;
	}
	public void setExshowroomprice(long exshowroomprice) {
		this.exshowroomprice = exshowroomprice;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public long getOnroadprice() {
		return onroadprice;
	}
	public void setOnroadprice(long onroadprice) {
		this.onroadprice = onroadprice;
	}
	public String getVariant() {
		return variant;
	}
	public void setVariant(String variant) {
		this.variant = variant;
	}
	public int getIncomeId() {
		return incomeId;
	}
	public void setIncomeId(int incomeId) {
		this.incomeId = incomeId;
	}
	
}
