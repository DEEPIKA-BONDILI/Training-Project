package com.example.demo1.layer3;
import java.util.*;

import org.springframework.stereotype.Repository;

import com.example.demo1.layer2.LoantrackerTable;
@Repository
public interface LoanTrackerTableRepo {
	void addLoantrackerDetails(LoantrackerTable ltRef);
	LoantrackerTable findLoantrackerDetails(int ltno);
	Set<LoantrackerTable>findAllLoantrackerDetails();
	void modifyLoantrackerDetails(LoantrackerTable ltRef);
	void removeLoantrackerDetails(int ltno);
	Set<LoantrackerTable> findLoanAppIdByUserId(int i);
	
}
