package com.example.demo1.layer2.dto;

import javax.persistence.Column;

public class DocTableDTO {
	
	private int docId;
	private String adhaarCard;
	private String panCard;
	private String salaryslip;
    private int userId;
	public int getDocId() {
		return docId;
	}
	public void setDocId(int docId) {
		this.docId = docId;
	}
	public String getAdhaarCard() {
		return adhaarCard;
	}
	public void setAdhaarCard(String adhaarCard) {
		this.adhaarCard = adhaarCard;
	}
	public String getPanCard() {
		return panCard;
	}
	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}
	public String getSalaryslip() {
		return salaryslip;
	}
	public void setSalaryslip(String salaryslip) {
		this.salaryslip = salaryslip;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}

}
