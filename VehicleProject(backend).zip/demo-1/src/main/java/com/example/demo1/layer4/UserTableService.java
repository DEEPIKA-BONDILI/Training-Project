package com.example.demo1.layer4;

import java.util.Set;


import org.springframework.stereotype.Service;
import com.example.demo1.layer2.UserTable;
import com.example.demo1.layer2.dto.LoginDTO;
import com.example.demo1.layer4.exceptions.UserNotFoundException;
import com.example.demo1.layer4.exceptions.UserAlreadyExistException;

@Service
public interface UserTableService // POJO crud interface
	{
		String addUserService(UserTable uRef) throws UserAlreadyExistException;		//	C - add - insert
		UserTable findUserService(LoginDTO logUser) throws UserNotFoundException;			//  R - find - select
		UserTable findUserService(int userId) throws UserNotFoundException;			//  R - find - select
		Set<UserTable> findUsersService();			//  R - find - select all
		String modifyUserService(UserTable uRef)throws UserNotFoundException;		//  U - modify - update
		String removeUserService(int uno)  throws UserNotFoundException  ; //  D - remove - delete

}