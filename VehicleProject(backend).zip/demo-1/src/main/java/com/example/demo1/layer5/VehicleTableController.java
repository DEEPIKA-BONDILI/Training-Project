package com.example.demo1.layer5;


import java.util.HashMap;
import java.util.Map;
import java.util.Set;

//import org.springframework.web.bind.annotation.*;
//import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.HeadersBuilder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo1.layer2.Vehicletable;
import com.example.demo1.layer2.dto.VehicletableDTO;
import com.example.demo1.layer4.VehicleTableService;
import com.example.demo1.layer4.exceptions.VehicleAlreadyExistException;
import com.example.demo1.layer4.exceptions.VehicleNotFoundException;

@CrossOrigin(origins="http://localhost:4200")
@RestController  //REpresentational State Transfer html xml json
public class VehicleTableController {

	@Autowired
	VehicleTableService vehicleServ;
	
	@GetMapping(path="/getVehicle/{myvno}") //Get Request in Postman http://localhost:8080/getLoan/1
	@ResponseBody
	public ResponseEntity<Vehicletable> getVehicle(@PathVariable("myvno") Integer lno) throws VehicleNotFoundException  {
		System.out.println("Vehicle Controller....Understanding client and talking to service layer...");
		Vehicletable vehicle = null;
		vehicle =vehicleServ.findVehicleService(lno);
			if(vehicle == null) {
				Map m = new HashMap();
				m.put("message",  "Vehicle Not found");
				//HeadersBuilder hb = ResponseEntity.notFound();
				
				HttpStatus status =HttpStatus.NOT_FOUND;
				//return new ResponseEntity(m,status);
				return ResponseEntity.notFound().build();
				//return new 
				
			}
			else {
				return ResponseEntity.ok(vehicle);
			}
	}
	
	
	@GetMapping(path="/getVehicles")
	@ResponseBody
	public Set<Vehicletable> getAllVehicles() {
		System.out.println("Vehicle Controller....Understanding client and talking to service layer...");
		Set<Vehicletable> vehicleList = vehicleServ.findVehicleService();
		return vehicleList;
		
	}
	
	@PostMapping(path="/addVehicle")
	public String addVehicle(@RequestBody VehicletableDTO vDTO) {
		
		String statusMsg = null;
		try {
			statusMsg =vehicleServ.addVehicleService(vDTO);
		} catch (VehicleAlreadyExistException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return statusMsg;
		
	}
	
	@PutMapping(path="/modifyVehicle")
	public String modifyVehicle(@RequestBody Vehicletable vehicle) {
		String statusMsg = null;
		try {
			statusMsg = vehicleServ.modifyVehicleService(vehicle);
		} catch (VehicleNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			return e.getMessage();
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return statusMsg;
		
	}
	
	@DeleteMapping(path="/deleteVehicle")
	public String deleteVehicle(@RequestBody Vehicletable vehicle ) {
		String statusMsg = null;
		try {
			statusMsg = vehicleServ.removeVehicleService(vehicle.getVehicleid());
		} catch (VehicleNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			return e.getMessage();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return statusMsg;
		
	}
	
}