package com.example.demo1.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.HashSet;
import java.util.Set;


/**
 * The persistent class for the INCOME_TABLE database table.
 * 
 */
@Entity
@Table(name="INCOME_TABLE")
@NamedQuery(name="IncomeTable.findAll", query="SELECT i FROM IncomeTable i")
public class IncomeTable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="INCOME_ID")
	private int incomeId;

	@Column(name="EMPLOYER_NAME")
	private String employerName;

	@Column(name="ORGANIZATION_TYPE")
	private String organizationType;

	@Column(name="TYPE_OF_EMP")
	private String typeOfEmp;

	//bi-directional many-to-one association to UserTable
	@ManyToOne
	@JoinColumn(name="USER_ID")
	private UserTable userTable;

	//bi-directional many-to-one association to Vehicletable
	@OneToMany(mappedBy="incomeTable", fetch=FetchType.EAGER, cascade = CascadeType.ALL)
	private Set<Vehicletable> vehicletables=new HashSet<Vehicletable>();

	public IncomeTable() {
	}

	public int getIncomeId() {
		return this.incomeId;
	}

	public void setIncomeId(int incomeId) {
		this.incomeId = incomeId;
	}

	public String getEmployerName() {
		return this.employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getOrganizationType() {
		return this.organizationType;
	}

	public void setOrganizationType(String organizationType) {
		this.organizationType = organizationType;
	}

	public String getTypeOfEmp() {
		return this.typeOfEmp;
	}

	public void setTypeOfEmp(String typeOfEmp) {
		this.typeOfEmp = typeOfEmp;
	}
	@JsonIgnore
	public UserTable getUserTable() {
		return this.userTable;
	}

	public void setUserTable(UserTable userTable) {
		this.userTable = userTable;
	}

	public Set<Vehicletable> getVehicletables() {
		return this.vehicletables;
	}

	public void setVehicletables(Set<Vehicletable> vehicletables) {
		this.vehicletables = vehicletables;
	}

	public Vehicletable addVehicletable(Vehicletable vehicletable) {
		getVehicletables().add(vehicletable);
		vehicletable.setIncomeTable(this);

		return vehicletable;
	}

	public Vehicletable removeVehicletable(Vehicletable vehicletable) {
		getVehicletables().remove(vehicletable);
		vehicletable.setIncomeTable(null);

		return vehicletable;
	}

}