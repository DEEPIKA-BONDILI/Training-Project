package com.example.demo1.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo1.layer2.DocTable;
import com.example.demo1.layer2.UserTable;
import com.example.demo1.layer2.dto.DocTableDTO;
import com.example.demo1.layer3.DocTableRepo;
import com.example.demo1.layer3.UserTableRepo;
import com.example.demo1.layer4.exceptions.DocumentAlreadyExistException;
import com.example.demo1.layer4.exceptions.DocumentNotFoundException;
@Service
public class DocTableServiceImpl implements DocTableService {
	
	@Autowired
	DocTableRepo documentRepo;
	
	@Autowired
	UserTableRepo userRepo;
	@Override
	public String addDocumentService(DocTableDTO docDTO) throws DocumentAlreadyExistException
	{
		System.out.println("Document Service....Some scope of bussiness logic here...");
		try {
			DocTable dRef = new DocTable();
			dRef.setDocId(docDTO.getDocId());
			dRef.setPanCard(docDTO.getPanCard());
			dRef.setAdhaarCard(docDTO.getAdhaarCard());
			dRef.setSalaryslip(docDTO.getSalaryslip());
			UserTable user = userRepo.findUser(docDTO.getUserId());
			user.getDocTables().add(dRef);
			dRef.setUserTable(user);
			documentRepo.modifyDocument(dRef);	
			} 
		catch (Exception e) {		
				throw new DocumentAlreadyExistException("Document Already Exist");
			}
			return "Document added successfully";
	}
	
	@Override
	public DocTable findDocumentService(int dno) throws  DocumentNotFoundException
	{
			System.out.println("Document Service....Some scope of bussiness logic here...");
			DocTable doc = documentRepo.findDocument(dno);
			if(doc == null) {
				throw new DocumentNotFoundException("Document Not Found");
			}
			return doc;
			
	}
		
	@Override
	public Set<DocTable> findDocumentServices() 
	{	
		System.out.println("Document Service....Some scope of bussiness logic here...");
		return documentRepo.findDocuments();
	}
		
	@Override
	public String modifyDocumentService(DocTable dRef) throws  DocumentNotFoundException 
	{	
		DocTable doc = documentRepo.findDocument(dRef.getDocId());
		if(doc == null) {
				throw new DocumentNotFoundException("Document Not Found");
				
	}
		else 
		{
			documentRepo.modifyDocument(dRef);
		}
				
		return "Document modifed successfully";
	}
	@Override
	public String removeDocumentService(int dno) throws  DocumentNotFoundException
	{	
			DocTable doc = documentRepo.findDocument(dno);
			if(doc == null)
			{
				throw new DocumentNotFoundException("Document Not Found");	
			}
			else {
				documentRepo.removeDocument(dno);
			}
				
			 return "Document Deleted successfully";
	}

/*	@Override
	public Set<DocTable> findDocByUserIdService(int dno) {
		
		Set<DocTable> doc = documentRepo.findDocumentByUserId(dno);
		if(doc == null)
		{
			throw new UserNotFoundException("User Not Found");	
		}
		else {
			documentRepo.findDocumentByUserId(dno);
		}
		//Set<Employee2> empSet =dept.getEmpSet();
		Set<DocTable> docSet=  doc.getdocSet();
		return null;
		Set<DocTable> docSet;
		Query query = entityManager.createQuery("from DocTable e where rep_id =:myno",DocTable.class).setParameter("myno", dno);
		docSet = new HashSet(query.getResultList());	
		return docSet;
	}*/

}