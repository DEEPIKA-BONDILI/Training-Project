package com.example.demo1.layer3;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.example.demo1.layer2.Vehicletable;

@Repository
public interface VehicleTableRepo {

 	void addVehicle(Vehicletable vRef);
	Vehicletable findVehicle(int vno);			
	Set<Vehicletable> findVehicles();			
	void modifyVehicle(Vehicletable vRef);
	void removeVehicle(int vno);
	Set<Vehicletable> findVehicleByUserId(int v);
	
}
