package com.example.demo1.layer4;

import java.util.Set;

import com.example.demo1.layer2.LoantrackerTable;
import com.example.demo1.layer2.dto.LoantrackerTableDTO;
import com.example.demo1.layer4.exceptions.LoanTrackerAlreadyExistException;
import com.example.demo1.layer4.exceptions.LoanTrackerNotFoundException;

public interface LoanTrackerTableService {
		String addLoanTrackerService(LoantrackerTableDTO ltDTO)throws LoanTrackerAlreadyExistException;  //C - add/create;
		LoantrackerTable findLoanTrackerService(int lno)throws LoanTrackerNotFoundException ;			//  R - find - select
		Set<LoantrackerTable> findLoanTrackersService();			//  R - find - select all
		String modifyLoanTrackerService(LoantrackerTable lRef) throws LoanTrackerNotFoundException;		//  U - modify - update
		String removeLoanTrackerService(int lno) throws LoanTrackerNotFoundException;
		
	}
