package com.example.demo1.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.example.demo1.layer2.UserTable;

@Repository
public interface UserTableRepo {
	void addUser(UserTable uRef);
	void removeUser(int uno);
	void modifyUser(UserTable uRef);
	UserTable findUser(int uno);
	Set<UserTable>findUsers();
}
