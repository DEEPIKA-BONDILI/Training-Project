package com.example.demo1.layer3;


import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo1.layer2.DocTable;

@Repository
public class DocTableRepoImpl implements DocTableRepo {

@PersistenceContext
EntityManager entityManager;

@Transactional
public void addDocument(DocTable dRef) {
entityManager.persist(dRef);

}
@Transactional
public DocTable findDocument(int dno) {
System.out.println("Department repo....NO scope of bussiness logic here...");
return entityManager.find(DocTable.class,dno);

}
@SuppressWarnings({ "rawtypes", "unchecked" })
@Transactional
public Set<DocTable> findDocuments()
{
Set<DocTable> docSet;
docSet = new HashSet<DocTable>();
String queryString = "from DocTable";
Query query = entityManager.createQuery(queryString);
docSet = new HashSet(query.getResultList());
return docSet;
}

@Transactional
public void modifyDocument(DocTable dRef)
{
entityManager.merge(dRef);

}

@Transactional
public void removeDocument(int dno)
{

DocTable dTemp = entityManager.find(DocTable.class,dno);
entityManager.remove(dTemp);
}
@SuppressWarnings({ "rawtypes", "unchecked" })
@Transactional
public Set<DocTable> findDocumentByUserId(int i)
{
Set<DocTable> docSet;
Query query = entityManager.createQuery("from DocTable e where rep_id =:myno",DocTable.class).setParameter("myno", i);
docSet = new HashSet(query.getResultList());
return docSet;
}
}



