package com.example.demo1.layer3;
import java.util.*;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo1.layer2.UserTable;


@Repository
public class UserTableRepoImpl implements UserTableRepo {
	@PersistenceContext()
	EntityManager entityManager;
	@Transactional
	public void addUser(UserTable uRef)
	{
	entityManager.persist(uRef);
	}
	@Transactional
	public UserTable findUser(int uno)
	{
	System.out.println("User repo..No scope of business logic here...");
	return
	entityManager.find(UserTable.class,uno);
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional
	public Set<UserTable> findUsers()
	{
	Set<UserTable> userSet;
	userSet = new HashSet<UserTable>();
	String queryString = "from UserTable";
	Query query = entityManager.createQuery(queryString);
	userSet = new HashSet(query.getResultList());
	return userSet;
	}
	@Transactional 
	public void modifyUser(UserTable uRef) {
	
		entityManager.merge(uRef);
		}
	@Transactional
	public void removeUser(int uno)
	{
	UserTable uTemp = entityManager.find(UserTable.class,uno);
	entityManager.remove(uTemp);
	}
	}




