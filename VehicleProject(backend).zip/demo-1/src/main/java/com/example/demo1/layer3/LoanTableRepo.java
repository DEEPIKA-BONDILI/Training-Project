package com.example.demo1.layer3;

import java.util.*;

import org.springframework.stereotype.Repository;

import com.example.demo1.layer2.LoanTable;

@Repository
public interface LoanTableRepo {
	void addLoanDetails(LoanTable lRef);
	LoanTable findLoanDetails(int lno);
	Set<LoanTable>findAllLoanDetails();
	void modifyLoanDetails(LoanTable lRef);
	void removeLoanDetails(int lno);

}
