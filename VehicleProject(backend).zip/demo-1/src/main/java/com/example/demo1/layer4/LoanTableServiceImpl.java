package com.example.demo1.layer4;

import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo1.layer3.DocTableRepo;
import com.example.demo1.layer3.IncomeTableRepo;
import com.example.demo1.layer3.LoanTableRepo;
import com.example.demo1.layer3.UserTableRepo;
import com.example.demo1.layer3.VehicleTableRepo;
import com.example.demo1.layer2.IncomeTable;
import com.example.demo1.layer2.LoanTable;
import com.example.demo1.layer2.UserTable;
import com.example.demo1.layer2.Vehicletable;
import com.example.demo1.layer2.dto.LoanTableDTO;
import com.example.demo1.layer4.exceptions.LoanAlreadyExistException;
import com.example.demo1.layer4.exceptions.LoanNotFoundException;

@Service
public class LoanTableServiceImpl implements LoanTableService {
	@Autowired
	LoanTableRepo loanRepo;
	
	@Autowired
	UserTableRepo userRepo;
	
	@Autowired
	VehicleTableRepo vRepo;
	
	@Autowired
	IncomeTableRepo incomeRepo;
	
	@Override
	public String addLoanService(LoanTableDTO loanDTO) throws LoanAlreadyExistException {
		System.out.println("Loan Service....Some scope of bussiness logic here...");
		try {
			
			LoanTable loan = new LoanTable();
			loan.setLoanId(loanDTO.getLoanId());
			loan.setMaxLoan(loanDTO.getMaxLoan());
			loan.setInterestRate(loanDTO.getInterestRate());
			loan.setTenure(loanDTO.getTenure());
			loan.setLoanAmount(loanDTO.getLoanAmount());
			IncomeTable income = incomeRepo.findIncome(loanDTO.getLoanId());
			UserTable user = userRepo.findUser(loanDTO.getLoanId());
			Vehicletable vehicle = vRepo.findVehicle(loanDTO.getVehicleid());
			if(income.getUserTable()==user) {
				if(vehicle.getIncomeTable()==income)
				{
					vehicle.getLoanTables().add(loan);
					loan.setVehicletable(vehicle);
					loanRepo.modifyLoanDetails(loan);
				}
			}
		} 
		catch (Exception e) {
			throw new LoanAlreadyExistException("Loan Already Exist");
		}
		return "Loan added successfully";
		}
	@Override
	public LoanTable findLoanService(int lno) throws LoanNotFoundException {
		
		System.out.println("Loan Service....Some scope of bussiness logic here...");
		LoanTable loan = loanRepo.findLoanDetails(lno);
		if(loan == null)
		{
			throw new LoanNotFoundException("Loan Not Found");
		}
		return loan;
		}
	
	@Override
	public String modifyLoanService(LoanTable lRef) throws LoanNotFoundException {
		LoanTable loan = loanRepo.findLoanDetails(lRef.getLoanId());
		if(loan == null)
		{
			throw new LoanNotFoundException("Loan Not Found");
		}
		else {
			loanRepo.modifyLoanDetails(lRef);
		}	
		return "Loan modifed successfully";
		}
	@Override
	public String removeLoanService(int lno) throws LoanNotFoundException{
		LoanTable loan = loanRepo.findLoanDetails(lno);
		if(loan == null) 
		{
			throw new LoanNotFoundException("Loan Not Found");
		}
		else
		{
		loanRepo.removeLoanDetails(lno);
		}			
		return "Loan Deleted successfully";
		}
	@Override
	public Set<LoanTable> findAllLoansService() {
		System.out.println("Loan Service....Some scope of bussiness logic here...");
		return loanRepo.findAllLoanDetails();
	}
	
}