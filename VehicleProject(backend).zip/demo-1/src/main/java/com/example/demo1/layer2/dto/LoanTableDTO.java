package com.example.demo1.layer2.dto;

import javax.persistence.Column;

public class LoanTableDTO {

	private int loanId;
	private float interestRate;
	private double loanAmount;
	private double maxLoan;
	private int tenure;
	private int vehicleid;
	public int getLoanId() {
		return loanId;
	}
	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}
	public float getInterestRate() {
		return interestRate;
	}
	public void setInterestRate(float interestRate) {
		this.interestRate = interestRate;
	}
	public double getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}
	public double getMaxLoan() {
		return maxLoan;
	}
	public void setMaxLoan(double maxLoan) {
		this.maxLoan = maxLoan;
	}
	public int getTenure() {
		return tenure;
	}
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	public int getVehicleid() {
		return vehicleid;
	}
	public void setVehicleid(int vehicleid) {
		this.vehicleid = vehicleid;
	}
	
}
