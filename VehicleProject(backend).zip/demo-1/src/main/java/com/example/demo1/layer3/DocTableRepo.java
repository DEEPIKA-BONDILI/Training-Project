package com.example.demo1.layer3;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.example.demo1.layer2.DocTable;

@Repository
public interface DocTableRepo {

	void addDocument(DocTable dRef);
	DocTable findDocument(int dno);
	Set<DocTable> findDocuments();
	void modifyDocument(DocTable dRef);
	void removeDocument(int dno);
	Set<DocTable> findDocumentByUserId(int dno);
	
}

