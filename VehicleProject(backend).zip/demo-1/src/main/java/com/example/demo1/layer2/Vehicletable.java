package com.example.demo1.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.HashSet;
import java.util.Set;


/**
 * The persistent class for the VEHICLETABLE database table.
 * 
 */
@Entity
@NamedQuery(name="Vehicletable.findAll", query="SELECT v FROM Vehicletable v")
public class Vehicletable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int vehicleid;

	private String color;

	private String company;

	private long exshowroomprice;

	private String model;

	private long onroadprice;

	private String variant;

	//bi-directional many-to-one association to LoanTable
	@OneToMany(mappedBy="vehicletable", fetch=FetchType.EAGER)
	private Set<LoanTable> loanTables=new HashSet<LoanTable>();

	//bi-directional many-to-one association to IncomeTable
	@ManyToOne
	@JoinColumn(name="INCOME_ID")
	private IncomeTable incomeTable;

	public Vehicletable() {
	}

	public int getVehicleid() {
		return this.vehicleid;
	}

	public void setVehicleid(int vehicleid) {
		this.vehicleid = vehicleid;
	}

	public String getColor() {
		return this.color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getCompany() {
		return this.company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public long getExshowroomprice() {
		return this.exshowroomprice;
	}

	public void setExshowroomprice(long exshowroomprice) {
		this.exshowroomprice = exshowroomprice;
	}

	public String getModel() {
		return this.model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public long getOnroadprice() {
		return this.onroadprice;
	}

	public void setOnroadprice(long onroadprice) {
		this.onroadprice = onroadprice;
	}

	public String getVariant() {
		return this.variant;
	}

	public void setVariant(String variant) {
		this.variant = variant;
	}

	public Set<LoanTable> getLoanTables() {
		return this.loanTables;
	}

	public void setLoanTables(Set<LoanTable> loanTables) {
		this.loanTables = loanTables;
	}

	public LoanTable addLoanTable(LoanTable loanTable) {
		getLoanTables().add(loanTable);
		loanTable.setVehicletable(this);

		return loanTable;
	}

	public LoanTable removeLoanTable(LoanTable loanTable) {
		getLoanTables().remove(loanTable);
		loanTable.setVehicletable(null);

		return loanTable;
	}
	@JsonIgnore
	public IncomeTable getIncomeTable() {
		return this.incomeTable;
	}

	public void setIncomeTable(IncomeTable incomeTable) {
		this.incomeTable = incomeTable;
	}

}