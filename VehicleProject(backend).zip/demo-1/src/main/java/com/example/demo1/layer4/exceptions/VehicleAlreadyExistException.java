package com.example.demo1.layer4.exceptions;

@SuppressWarnings("serial")
public class VehicleAlreadyExistException extends Exception {

	public VehicleAlreadyExistException(String message) {
		super(message);
		System.out.println("Vehicle Already Exist.........");
	}

}
