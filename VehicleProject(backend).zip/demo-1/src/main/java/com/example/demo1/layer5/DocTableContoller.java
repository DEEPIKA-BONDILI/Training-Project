package com.example.demo1.layer5;


import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo1.layer2.DocTable;
import com.example.demo1.layer2.LoantrackerTable;
import com.example.demo1.layer2.UserTable;
import com.example.demo1.layer2.dto.DocTableDTO;
import com.example.demo1.layer3.UserTableRepo;
import com.example.demo1.layer4.DocTableService;
import com.example.demo1.layer4.exceptions.DocumentAlreadyExistException;
import com.example.demo1.layer4.exceptions.DocumentNotFoundException;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class DocTableContoller {

	@Autowired
	DocTableService docServ;

	@Autowired
	UserTableRepo userRepo;


	@GetMapping(path="/getDoc/{mydno}")
	@ResponseBody
public ResponseEntity<DocTable> getDocument(@PathVariable("mydno") Integer dno) throws DocumentNotFoundException {
			System.out.println("Document  Controller....Understanding client and talking to service layer...");
			DocTable doc=null;

			doc = docServ.findDocumentService(dno);
			if(doc==null)
			{
				return ResponseEntity.notFound().build();

			}
			else {
				return ResponseEntity.ok(doc);
			}

	}


	@GetMapping(path="/getDocs")
	@ResponseBody
	public Set<DocTable> getAllDocuments() {
		System.out.println("Document Controller....Understanding client and talking to service layer...");
		Set<DocTable> docSet = docServ.findDocumentServices();
		return docSet;

	}

	@GetMapping(path="/getLoantrackersOfDoc")
	@ResponseBody
	public Set<LoantrackerTable> getAllloantrackersbydocid() {
		System.out.println("Document Controller....Understanding client and talking to service layer...");
		DocTable doc=null;
		try {
				doc = docServ.findDocumentService(701);
		} catch (DocumentNotFoundException e) {
			e.printStackTrace();
		}
		Set<LoantrackerTable> loanSet =doc.getLoantrackerTables();
		return loanSet;
	 }

		@PostMapping(path="/addDoc")
		public String addDocument(@RequestBody DocTableDTO docDTO) {
			System.out.println("Document Controller....Understanding client and talking to service layer...");
//			DocTable document=new DocTable();
//			document.setDocId(doc.getDocId());
//			document.setPanCard(doc.getPanCard());
//			document.setSalaryslip(doc.getSalaryslip());
//			document.setAdhaarCard(doc.getAdhaarCard());
//			UserTable user=userRepo.findUser(101);
//			document.setUserTable(user);

			String stmsg = null;
			try {
				stmsg = docServ.addDocumentService(docDTO);
			}
			catch (DocumentAlreadyExistException e) {
				e.printStackTrace();
				return e.getMessage();
			}
			catch(Exception e) {
				e.printStackTrace();
				return e.getMessage();
			}
			System.out.println("controller printing"+stmsg);
			return stmsg;

}

		@PutMapping(path="/modifyDoc")
		public String modifyDocument(@RequestBody DocTable doc)throws DocumentNotFoundException {
			System.out.println("Document Controller....Understanding client and talking to service layer...");
			String stmsg = null;
			try {
				stmsg = docServ.modifyDocumentService(doc);


			}
			catch (DocumentNotFoundException e) {

				e.printStackTrace();
				return e.getMessage();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			System.out.println("controller is saying: "+stmsg);
			return stmsg;

		}

		@DeleteMapping(path="/deleteDoc")
		public String removeDocument(@RequestBody DocTable doc)throws DocumentNotFoundException {
			System.out.println("Document Controller....Understanding client and talking to service layer...");
			String stmsg = null;
			try {
				stmsg = docServ.removeDocumentService(doc.getDocId());
			}
			catch (DocumentNotFoundException e) {
				e.printStackTrace();
				return e.getMessage();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			System.out.println("controller is saying: "+stmsg);
			return stmsg;

		}

		@DeleteMapping(path="/deleteDocById/{mydno}")
		@ResponseBody
		public String removeDocumentbyId(@PathVariable("mydno")Integer dno)throws DocumentNotFoundException {
			System.out.println("Document Controller....Understanding client and talking to service layer...");
			String stmsg = null;
			try {
				stmsg = docServ.removeDocumentService(dno);
			}
			catch (DocumentNotFoundException e) {
				e.printStackTrace();
				return e.getMessage();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			System.out.println("controller is saying: "+stmsg);
			return stmsg;

		}
}
