package com.example.demo1.layer3;

import java.util.*;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo1.layer2.LoanTable;

@Repository
public class LoanTableRepoImpl implements LoanTableRepo {

@PersistenceContext
	 EntityManager entityManager;
										
	
	@Transactional
	public void addLoanDetails(LoanTable lRef) {
		entityManager.persist(lRef);

	}
	
	@Transactional
	public LoanTable findLoanDetails(int lno) {
		System.out.println("LoanTable Repository....NO scope of bussiness logic here...");
		return entityManager.find(LoanTable.class,lno);
		
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Transactional
	public Set<LoanTable> findAllLoanDetails()
	{
	Set<LoanTable> loanSet;
	loanSet = new HashSet<LoanTable>();
	String queryString = "from LoanTable";
	Query query = entityManager.createQuery(queryString);
	loanSet = new HashSet(query.getResultList());
	return loanSet;
	}
		
		
	
	
	@Transactional
	public void modifyLoanDetails(LoanTable lRef) {
		entityManager.merge(lRef);

	}

	@Transactional
	public void removeLoanDetails(int lno) {
		LoanTable dTemp = entityManager.find(LoanTable.class,lno);
		entityManager.remove(dTemp);
		
	}

}
