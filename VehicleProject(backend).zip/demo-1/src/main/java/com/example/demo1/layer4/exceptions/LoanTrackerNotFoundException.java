package com.example.demo1.layer4.exceptions;

@SuppressWarnings("serial")
public class LoanTrackerNotFoundException extends Exception {

	public LoanTrackerNotFoundException(String message) {
		super(message);
		System.out.println("Loan Tracker Not Found.........");
	}

}