package com.example.demo1.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo1.layer2.DocTable;
import com.example.demo1.layer2.LoantrackerTable;
import com.example.demo1.layer2.dto.LoantrackerTableDTO;
import com.example.demo1.layer3.DocTableRepo;
import com.example.demo1.layer3.LoanTrackerTableRepo;
import com.example.demo1.layer4.exceptions.LoanTrackerAlreadyExistException;
import com.example.demo1.layer4.exceptions.LoanTrackerNotFoundException;


 @Service
public class LoanTrackerTableServiceImpl implements LoanTrackerTableService {

    	@Autowired	
    	LoanTrackerTableRepo  loanTrackerRepo;
    	@Autowired
    	DocTableRepo docRepo;
    	
   		@Override
		public String addLoanTrackerService(LoantrackerTableDTO ltDTO) throws LoanTrackerAlreadyExistException {
			
				System.out.println("LoanTracker Service....Some scope of bussiness logic here...");
				try {
					LoantrackerTable loantrcr = new LoantrackerTable();
					loantrcr.setAccNo(ltDTO.getAccNo());
					loantrcr.setLoanappId(ltDTO.getLoanappId());
					loantrcr.setLoanApprovalDate(ltDTO.getLoanApprovalDate());
					loantrcr.setFinalId(ltDTO.getFinalId());
					DocTable doc = docRepo.findDocument(ltDTO.getDocId());
					doc.getLoantrackerTables().add(loantrcr);
					loantrcr.setDocTable(doc);
					loanTrackerRepo.addLoantrackerDetails(loantrcr);
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					throw new LoanTrackerAlreadyExistException("LoanTracker Already Exsist");
				}
				return "LoanTracker added successfully";
			}
			
			

   		@Transactional
		public LoantrackerTable findLoanTrackerService(int lno) throws LoanTrackerNotFoundException {
				System.out.println("LoanTracker repo....NO scope of bussiness logic here...");
				LoantrackerTable loanTracker = loanTrackerRepo.findLoantrackerDetails(lno);
				if(loanTracker == null) {
					throw new LoanTrackerNotFoundException("LoanTracker Not Found");
				}
				return loanTracker;
			}
			
	 
		@Transactional
		public String modifyLoanTrackerService(LoantrackerTable lRef)throws LoanTrackerNotFoundException {
				LoantrackerTable loanTracker = loanTrackerRepo.findLoantrackerDetails(lRef.getFinalId());
				if(loanTracker == null) {
					throw new LoanTrackerNotFoundException("LoanTracker Not Found");
					
				}
				else {
					loanTrackerRepo.modifyLoantrackerDetails(lRef);
				}
			
			return "LoanTracker modifed successfully";
        }

		@Transactional
		public String removeLoanTrackerService(int lno)throws LoanTrackerNotFoundException {
				LoantrackerTable loanTracker = loanTrackerRepo.findLoantrackerDetails(lno);
				if(loanTracker == null) {
					throw new LoanTrackerNotFoundException("LoanTracker Not Found");
					
				}
				else {
					loanTrackerRepo.removeLoantrackerDetails(lno);
				}
					
			return "LoanTracker Deleted successfully";

		  }



		@Override
		public Set<LoantrackerTable> findLoanTrackersService() {
			
			return loanTrackerRepo.findAllLoantrackerDetails();
		}
		
   		
	

	}