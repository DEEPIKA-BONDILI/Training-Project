package com.example.demo1.layer4;

import java.util.Set;
import org.springframework.stereotype.Service;
import com.example.demo1.layer4.exceptions.LoanAlreadyExistException;
import com.example.demo1.layer4.exceptions.LoanNotFoundException;
import com.example.demo1.layer2.LoanTable;
import com.example.demo1.layer2.dto.LoanTableDTO;


@Service
public interface LoanTableService {

	String addLoanService(LoanTableDTO loanDTO) throws LoanAlreadyExistException;		
	LoanTable findLoanService(int lno) throws LoanNotFoundException;			
	Set<LoanTable> findAllLoansService();			
	String modifyLoanService(LoanTable lRef) throws LoanNotFoundException;		
	String removeLoanService(int lno) throws LoanNotFoundException;     
}