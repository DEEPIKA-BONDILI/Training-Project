package com.example.demo1.layer4;
import java.util.Set;
import org.springframework.stereotype.Service;
import com.example.demo1.layer2.IncomeTable;
import com.example.demo1.layer2.dto.IncomeTableDTO;
import com.example.demo1.layer4.exceptions.IncomeAlreadyExistException;
import com.example.demo1.layer4.exceptions.IncomeNotFoundException;

@Service
public interface IncomeTableService {
	String addIncomeService(IncomeTableDTO inc) throws IncomeAlreadyExistException;   //C - add/create
	IncomeTable findIncomeService(int dno)throws IncomeNotFoundException;     //R - find/reading
	Set<IncomeTable> findIncomesService();     //R - find all/reading all
	String modifyIncomeService(IncomeTableDTO inc)throws IncomeNotFoundException; //U - modify/update
	String removeIncomeService(int dno)throws IncomeNotFoundException; //D - remove/delete
}