package com.example.demo1.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the LOAN_TABLE database table.
 * 
 */
@Entity
@Table(name="LOAN_TABLE")
@NamedQuery(name="LoanTable.findAll", query="SELECT l FROM LoanTable l")
public class LoanTable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LOAN_ID")
	private int loanId;

	@Column(name="INTEREST_RATE")
	private float interestRate;

	@Column(name="LOAN_AMOUNT")
	private double loanAmount;

	@Column(name="MAX_LOAN")
	private double maxLoan;

	private int tenure;

	//bi-directional many-to-one association to Vehicletable
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="VEHICLEID")
	private Vehicletable vehicletable;

	public LoanTable() {
	}

	public int getLoanId() {
		return this.loanId;
	}

	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}

	public float getInterestRate() {
		return this.interestRate;
	}

	public void setInterestRate(float interestRate) {
		this.interestRate = interestRate;
	}

	public double getLoanAmount() {
		return this.loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public double getMaxLoan() {
		return this.maxLoan;
	}

	public void setMaxLoan(double maxLoan) {
		this.maxLoan = maxLoan;
	}

	public int getTenure() {
		return this.tenure;
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	@JsonIgnore
	public Vehicletable getVehicletable() {
		return this.vehicletable;
	}

	public void setVehicletable(Vehicletable vehicletable) {
		this.vehicletable = vehicletable;
	}

}