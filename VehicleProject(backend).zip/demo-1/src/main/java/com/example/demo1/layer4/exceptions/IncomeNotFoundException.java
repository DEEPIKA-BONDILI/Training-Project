package com.example.demo1.layer4.exceptions;



@SuppressWarnings("serial")
public class IncomeNotFoundException extends Exception{

	public IncomeNotFoundException(String message)
	{
		super(message);
		System.out.println("Income Not Found ..............");
	}
}