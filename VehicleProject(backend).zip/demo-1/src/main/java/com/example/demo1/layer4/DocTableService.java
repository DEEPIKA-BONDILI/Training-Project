package com.example.demo1.layer4;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.example.demo1.layer4.exceptions.DocumentAlreadyExistException;
import com.example.demo1.layer4.exceptions.DocumentNotFoundException;
import com.example.demo1.layer2.DocTable;
import com.example.demo1.layer2.dto.DocTableDTO;

@Service
public interface DocTableService {
	
		    String addDocumentService(DocTableDTO docDTO) throws DocumentAlreadyExistException;
			DocTable findDocumentService(int dno) throws DocumentNotFoundException; 			
			Set<DocTable> findDocumentServices();			
			String modifyDocumentService(DocTable dRef) throws DocumentNotFoundException; 
			String removeDocumentService(int dno) throws DocumentNotFoundException;
		
}
