package com.example.demo1.layer5;



import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo1.layer2.DocTable;
import com.example.demo1.layer2.IncomeTable;
import com.example.demo1.layer2.UserTable;
import com.example.demo1.layer2.dto.LoginDTO;
import com.example.demo1.layer4.UserTableService;
import com.example.demo1.layer4.exceptions.UserAlreadyExistException;
import com.example.demo1.layer4.exceptions.UserNotFoundException;
@CrossOrigin(origins="http://localhost:4200")
@RestController
public class UserTableController {
	
	@Autowired
	UserTableService userTableServ;
	
	
	@GetMapping(path="/getUser/{userId}")
	@ResponseBody
	public ResponseEntity<UserTable> getUserTable(@PathVariable("userId") int userId) throws UserNotFoundException {
		System.out.println("UserTable Controller....Understanding client and talking to service layer...");
		UserTable user=null;
		
			user = userTableServ.findUserService(userId);
			if(user==null)
			{ 
				return ResponseEntity.notFound().build();
			
			}
			else {
				return ResponseEntity.ok(user);
			}
		
	}
	
	
	
	@PostMapping(path="/findUser")
	@ResponseBody
	public ResponseEntity getUserTable(@RequestBody LoginDTO logDetails)  {
		System.out.println("UserTable Controller....Understanding client and talking to service layer...");
		UserTable user=null;
			System.out.println("Controller : "+logDetails.getUserId()+" : "+logDetails.getPassword());
			try {
				user = userTableServ.findUserService(logDetails);
				return ResponseEntity.ok(user);
			} catch (UserNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return ResponseEntity.notFound().build().ok(e.getMessage());
			}
	}
	
	@GetMapping(path="/getUsers")
	@ResponseBody
	public Set <UserTable>  getAllUsers() {
		System.out.println("User Controller....Understanding client and talking to service layer...");
		Set<UserTable> userSet = userTableServ.findUsersService();
		return userSet;
		
	}
	
	
	
	@PostMapping(path="/addUser")
	public String addUserTable(@RequestBody UserTable user) {
		System.out.println("User Controller....Understanding client and talking to service layer...");
		UserTable userTable=new UserTable();
	      user.setFname(user.getFname());
	      userTable.setMailid(user.getMailid());
	      userTable.setLname(user.getLname());
	      userTable.setMname(user.getMname());
	      userTable.setMailid(user.getMailid());
	      userTable.setGender(user.getGender());
	      userTable.setAddress(user.getAddress());
	      userTable.setAdharNo(user.getAdharNo());
	      userTable.setPassword(user.getPassword());
	      userTable.setConfirmPassword(user.getConfirmPassword());
	      userTable.setPanNo(user.getPanNo());
	      userTable.setPhoneno(user.getPhoneno());
              userTable.setNationality(user.getNationality());
              userTable.setDob(user.getDob());
	     
	      
		 String stmsg = null;
		try {
			stmsg = userTableServ.addUserService(user);
		} 
	 catch (UserAlreadyExistException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		System.out.println("controller printing"+stmsg);
		  return stmsg;
		
	}
		
	
	@PutMapping(path="/modifyUser")
	public String modifyUser(@RequestBody UserTable user)throws UserNotFoundException {
		System.out.println("User Controller....Understanding client and talking to service layer...");
		 String stmsg = null;
		try {
			stmsg = userTableServ.modifyUserService(user);
		} 
		catch (UserNotFoundException e) {
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("controller is saying: "+stmsg);
		  return stmsg;
		
	}
	@DeleteMapping(path="/deleteUser")
	public String removeUser(@RequestBody UserTable user)throws UserNotFoundException {
		System.out.println("User Controller....Understanding client and talking to service layer...");
		 String stmsg = null;
		try {
			stmsg = userTableServ.removeUserService(user.getUserId());
		} 
		catch (UserNotFoundException e) {
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("controller is saying: "+stmsg);
		  return stmsg;
		
	}
	@GetMapping(path="/getDocumentByUserId")
	@ResponseBody
	public Set<DocTable> getAllDocumentByUserId() {
		System.out.println("User Controller....Understanding client and talking to service layer...");
		UserTable user=null;
		try {
			user =userTableServ.findUserService(101);
		} catch (UserNotFoundException e) {
			e.printStackTrace();
		}
		Set<DocTable> docSet =user.getDocTables();
		return docSet;
		
	}
	
	@GetMapping(path="/IncomeByUserId")
	@ResponseBody
	public Set<IncomeTable> getAllLoanByUserId() {
		System.out.println("User Controller....Understanding client and talking to service layer...");
		UserTable user=null;
		try {
			user =userTableServ.findUserService(101);
		} catch (UserNotFoundException e) {
			e.printStackTrace();
		}
		Set<IncomeTable> loanSet =user.getIncomeTables();

		return loanSet;
		
	}
	
	

}
